import java.util.ArrayList;

//import com.nesterovskyBros.annotation.Yield;

/*public class Yeild {

	@Yield
	public static Iterable<Integer> generate(final int from, final int to)
	{
	  ArrayList<Integer> items = new ArrayList<Integer>();

	  for(int i = from; i < to; ++i)
	  {
	    items.add(i);
	  }

	  return items;
	}
	
	public static void main(String []args) {
		/*ArrayList<Integer> a= generate(7, 20);
		System.out.println();*/
		/*for(int value: generate(7, 20))
		{
		  System.out.println("generator: " + value);
		}
	}
	
}*/
