package TNApplication;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import Resource.ExtentReporterNG;
import Resource.Base;

import Resource.Base;

import org.testng.ITestListener;


public class ReportGenerator extends Base {

//	private ThreadLocal testWatcher= new ThreadLocal();
	static ExtentTest test;
	static ExtentReports extent=ExtentReporterNG.getReportObject();
	static ThreadLocal<ExtentTest> extentTest =new ThreadLocal<ExtentTest>();
	
	

	public static void onTestSuccess(String method) {
		test= extent.createTest(method);
		extentTest.set(test);
		extentTest.get().log(Status.PASS, "Test Passed");
		extent.flush();
	}

	public static void onTestFailure(Throwable throwable,String method) {
		test= extent.createTest(method);
		extentTest.set(test);
		extentTest.get().fail(throwable);
		
		try {
			extentTest.get().addScreenCaptureFromPath(getScreenShotPathStatic(method), method);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		extent.flush();
	}

	
	
	

}

	

