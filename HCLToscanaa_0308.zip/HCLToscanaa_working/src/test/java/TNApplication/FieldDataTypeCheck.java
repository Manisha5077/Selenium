package TNApplication;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITest;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.constant.ToscanaConstant;
import com.util.Utils;

import Resource.Base;
import Resource.ExtentReporterNG;

public class FieldDataTypeCheck extends Base implements ITest {
	
	WebDriverWait wait = new WebDriverWait(driver,50);

	static Map<String,List<String>> map=new HashMap<String,List<String>>();
	 static Map<String, List<String>> data=null;
	 static String saveXPath=null;

	   static  ExtentTest testReport;
		static ExtentReports extent=ExtentReporterNG.getReportObject();
		static ThreadLocal<ExtentTest> extentTest =new ThreadLocal<ExtentTest>();

	 
	 @BeforeClass
		public void clean_test_result() {
			//logger.info("FormSubmission: Inside clean_test_result()");
			 try {
				   TestCasesResultWrite.clean_test_result_visibility(ToscanaConstant.SubModule_DataType_check);
				
				   }catch(Exception E) {
					   //logger.error("FormSubmission: Inside clean_test_result(): error {}", E);
					   E.printStackTrace();
				   }
	 }

static
	
	{ 
		
		try {

			data = ExcelVisibleRead.readExcel(System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"), prop.getProperty("xlsx.file.name"),
					prop.getProperty("enable.sheet.name"));
			saveXPath=	Utils.propertyfromxls("Savebutton");

		} catch (IOException e) {

		}
		
		for (Map.Entry<String, List<String>> mapData : data.entrySet()) {

			map.put(mapData.getKey(), mapData.getValue());

		}
		
		
	}

        @Test
		public static void DataTypeCheck() {
	
        	System.out.println("******************************************************INSIDE DATATYPE CHECK*****************************************************");
		
		
		for(int i=0;i<map.size();i++) {
			
			
		try {
			List<String> mapList= map.get(data.keySet().toArray()[i]);
	        Object key = data.keySet().toArray()[i];
			
			if(mapList.get(1).equalsIgnoreCase("input")) {
				
		        //Round1 for alphabet
				boolean flag = false;
				boolean flag1=false;
				boolean flag2=false;
				boolean flag3=false;
				
				WebElement element=GenericMethod.Find_element(mapList.get(2),mapList.get(0));
				
				if(mapList.get(5).equalsIgnoreCase("alphabet")) {
					
                GenericMethod.sendkeys(mapList.get(2), mapList.get(0), Length.RandomAlphabeticString());
				int LengthAccepting= element.getAttribute("value").length();
				
				
				
				if(LengthAccepting>0) {
					
					flag1= true;
				}
					else 
					{
						flag1= false;
					}
					
					element.clear();
					
                      if(mapList.get(5).equalsIgnoreCase("alphabet")) {
						
		                GenericMethod.sendkeys(mapList.get(2), mapList.get(0), String.valueOf(Length.RandomNumeric()));
						int LengthAccepting1= element.getAttribute("value").length();
						if(LengthAccepting1>0) {
							
							flag3= false;
						}
						
						else 
						{
							flag3= true;
						}
						
						element.clear();
						
	                      if(mapList.get(5).equalsIgnoreCase("alphabet")) {
							
			                GenericMethod.sendkeys(mapList.get(2), mapList.get(0), String.valueOf(Length.RandomSymbolString()));
							int LengthAccepting3= element.getAttribute("value").length();
							if(LengthAccepting3>0) {
								
								flag3= false;
							}
							
							else 
							{
								flag3= true;
							}
						
						
						
						
				}
                      boolean CheckData=GenericMethod.returntrue(flag1, flag2, flag3);
                      try {
          				Assert.assertEquals(CheckData, true);
          				flag= true;
          				ReportGenerator.onTestSuccess("DataTypeCheck"+data.keySet().toArray()[i]);
          				}catch(Throwable throwable) {
          					flag= false;
          					ReportGenerator.onTestFailure(throwable, "DataTypeCheck"+data.keySet().toArray()[i]);
          				}

                      try {
                    	  
                    	  
      					TestCasesResultWrite.writeData3(String.valueOf(flag), ToscanaConstant.SubModule_DataType_check,String.valueOf(data.keySet().toArray()[i]));
      					
      					}catch(Exception E) {
      						E.printStackTrace();
      					}
                    	  
				}
				}
				
				//Round2 for Numeric
				
				if(mapList.get(5).equalsIgnoreCase("Numeric")) {
					
	                GenericMethod.sendkeys(mapList.get(2), mapList.get(0),String.valueOf(Length.RandomNumeric()) );
					int LengthAccepting= element.getAttribute("value").length();
					
					if(LengthAccepting>0) {
						
						flag1= true;
						
					}
					
					else 
					{
						flag1= false;
					}
						
						element.clear();
						
	                      if(mapList.get(5).equalsIgnoreCase("Numeric")) {
							
			                GenericMethod.sendkeys(mapList.get(2), mapList.get(0), String.valueOf(Length.RandomAlphabeticString()));
							int LengthAccepting1= element.getAttribute("value").length();
							if(LengthAccepting1>0) {
								
								flag2= false;
							}
				
							else 
							{
								flag2= true;
							}
				
							
							element.clear();
							
		                      if(mapList.get(5).equalsIgnoreCase("Numeric")) {
								
				                GenericMethod.sendkeys(mapList.get(2), mapList.get(0), String.valueOf(Length.RandomSymbolString()));
								int LengthAccepting3= element.getAttribute("value").length();
								if(LengthAccepting3>0) {
									
									flag3= false;
								}
								
								else 
								{
									flag3= true;
								}
							
							
							
							 boolean CheckData=GenericMethod.returntrue(flag1, flag2, flag3);
							 
							 
		                      try {
		          				Assert.assertEquals(CheckData, true);
		          				flag= true;
		          				ReportGenerator.onTestSuccess("DataTypeCheck_"+data.keySet().toArray()[i]);
		          				}catch(Throwable throwable) {
		          					flag= false;
		          					ReportGenerator.onTestFailure(throwable, "DataTypeCheck_"+data.keySet().toArray()[i]);
		          				}

	                      }
	                      
	                      try {
	      					
	      					TestCasesResultWrite.writeData3(String.valueOf(flag), ToscanaConstant.SubModule_DataType_check,String.valueOf(data.keySet().toArray()[i]));
	      					
	      					}catch(Exception E) {
	      						E.printStackTrace();
	      					}
				
					}
				}
			
				
				//Round3 for alphanumeric 
				
				if(mapList.get(5).equalsIgnoreCase("alphanumeric")) {
					
			    GenericMethod.sendkeys(mapList.get(2), mapList.get(0),String.valueOf(Length.RandomAlphanumericString()));
				
				int LengthAccepting=element.getAttribute("value").length();
               
				try {
     				Assert.assertEquals(LengthAccepting>0, true);
     				flag= true;
     				ReportGenerator.onTestSuccess("DataTypeCheck_"+data.keySet().toArray()[i]);
     				}catch(Throwable throwable) {
     					flag= false;
     					ReportGenerator.onTestFailure(throwable, "DataTypeCheck_"+data.keySet().toArray()[i]);
     				}


			 try {
					
					TestCasesResultWrite.writeData3(String.valueOf(flag), ToscanaConstant.SubModule_DataType_check,String.valueOf(data.keySet().toArray()[i]));
					
					}catch(Exception E) {
						E.printStackTrace();
					}
		
			}
			}
		}
		catch (Exception e) {
			
			System.out.println("e>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+e);
	
		}
		}
		}
	
		
		
	

	@Override
	public String getTestName() {

		return null;
	}
	
	
	
}
	
	
