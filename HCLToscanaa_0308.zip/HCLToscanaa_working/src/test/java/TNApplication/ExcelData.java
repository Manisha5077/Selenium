package TNApplication;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Resource.Base;

public class ExcelData extends Base {
	
	static List<String> data=null;
	 
	public static  Map<String, List<String>> readExcelInputData2(String filePath,String fileName,String sheetName) throws IOException{

    	int p=1;

    File file =    new File(filePath+"\\"+fileName);
    FileInputStream inputStream = new FileInputStream(file);
    Workbook myWorkbook = null;
    String fileExtensionName = fileName.substring(fileName.indexOf("."));
    if(fileExtensionName.equals(".xlsx")){
    myWorkbook = new XSSFWorkbook(inputStream);
    }

    else if(fileExtensionName.equals(".xls")){
        myWorkbook = new HSSFWorkbook(inputStream);
    }
    Sheet mysheet = myWorkbook.getSheet(sheetName);
    System.out.println("sheetName"+sheetName);
    int rowCount = mysheet.getLastRowNum()-mysheet.getFirstRowNum();       
       Map<String, List<String>> dataMap2 = new LinkedHashMap();
        Row row1 = mysheet.getRow(0);
  
        int cellcount=row1.getLastCellNum()-row1.getFirstCellNum();
        
       System.out.println("value of rowcount in excel input"+rowCount);
       
     data = ExcelVisibleRead.getWIList();
       
        for(p=1;p<=rowCount;p++) {
        	List<String> lt_data = new ArrayList();
        Row row = mysheet.getRow(p); 
        for(int q=0;q<cellcount;q++) {
  
        	if(row.getCell(q).getCellType()==row.getCell(q).getCellType().STRING) {
        		lt_data.add(row.getCell(q).getStringCellValue());
			}
			else {
	
				DataFormatter formatter = new DataFormatter(Locale.US);
				
				lt_data.add(formatter.formatCellValue(row.getCell(q)));
	
        }

        }
        lt_data.add(String.valueOf(p));
//System.out.println("data.size()+>>>>>>>>>>>>>>>>>>>>>>>"+data.size());

System.out.println("p+>>>>>>>>>>>>>>>>>>>>>>>"+p);

        dataMap2.put(data.get(p-1),lt_data);//all names are key here

  
        }
        
        

        System.out.println("datamap size in read 2>>>>>>>>"+dataMap2.size());
        GenericMethod.closeexcel(myWorkbook);
	return dataMap2;
        
    }
	

}
