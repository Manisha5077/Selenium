package TNApplication;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITest;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.constant.ToscanaConstant;
import com.util.Utils;

import Resource.Base;
import junit.framework.Assert;

public class MandatoryCheck extends Base implements ITest {

	WebDriverWait wait = new WebDriverWait(driver,10);
	private ThreadLocal<String> testName = new ThreadLocal<>();
	
	SoftAssert softAssertion = new SoftAssert();
	XSSFWorkbook result_workbook = null;
	 
	 static Map<String,List<String>> map=new HashMap<String,List<String>>();
 	 static Map<String, List<String>> data=null;
	 static String saveXPath=null;
	 static String AlertTextContains=Utils.propertyfromxls("AlertText");
	 
	 
	 
	 @BeforeClass
		public void clean_test_result() {
			//logger.info("FormSubmission: Inside clean_test_result()");
			 try {
				   TestCasesResultWrite.clean_test_result_visibility(ToscanaConstant.SubModule_mandatory_check);
				
				   }catch(Exception E) {
					   //logger.error("FormSubmission: Inside clean_test_result(): error {}", E);
					   E.printStackTrace();
				   }
	 }

static
	
	{ 
		
		try {

			data = ExcelVisibleRead.readExcel(System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"), prop.getProperty("xlsx.file.name"),
					prop.getProperty("enable.sheet.name"));
			saveXPath=	Utils.propertyfromxls("Savebutton");

		} catch (IOException e) {

		}
		
		for (Map.Entry<String, List<String>> mapData : data.entrySet()) {

			map.put(mapData.getKey(), mapData.getValue());

		}
	}
		
		@Test(dataProvider = "Mandatory-data-provider", dataProviderClass = DP.class, priority = 2)
		public void mandatoryCheck(String key, Map<List<String>, List<String>> rowDataMap) {
			
			
			System.out.println("******************************************************INSIDE MANDATORY CHECK*****************************************************");
			if (rowDataMap.isEmpty()) {
				return;
			}
			Map.Entry<List<String>, List<String>> entry = rowDataMap.entrySet().stream().findFirst().get();
			List<String> rowKey = entry.getKey();
			List<String> rowValue = entry.getValue();


		for (int i = 0; i < rowValue.size(); i++) {
	
			for (int j = 0; j < rowValue.size(); j++) {

				try {
					List<String> mapList = map.get(rowKey.get(j));// map.get(key), for sequence fix
		
					String value = "";
					if (i != j) {//0-0,1-1 blank else get value
						value = rowValue.get(j);
					}
					
					WebElement element = GenericMethod.Find_element(mapList.get(2), mapList.get(0));

					

					if (mapList.get(1).equalsIgnoreCase("input")) {

						GenericMethod.sendkeys(mapList.get(2), mapList.get(0), value);

					}

					else {
						GenericMethod.sendkeys_To_dropdown(mapList.get(2), mapList.get(0), value);
					}

				
				}

				catch (Exception e) {

				}
				
			}
						

				List<String> EnableListvalue = map.get(rowKey.get(i));
			String	mandatory= EnableListvalue.get(3);
						
				driver.findElement(By.xpath(saveXPath)).click();
	
				try {
					Thread.sleep(5000);
				} 
				catch (InterruptedException e) {
				
					e.printStackTrace();
					
				}
					  boolean Sucessflag=isAlertPresent();
					  boolean flag=false;
					  
					if (mandatory.equalsIgnoreCase("Yes")) {
						if(false==Sucessflag)
							flag=true;
						
						 try {
								
								TestCasesResultWrite.writeData3(String.valueOf(flag), ToscanaConstant.SubModule_mandatory_check,String.valueOf(rowKey.toArray()[i]));
								
								
								}catch(Exception E) {
									E.printStackTrace();
								}
			
						
						try {
							Assert.assertEquals(false, Sucessflag);
							flag= true;
								ReportGenerator.onTestSuccess("mandatoryCheck_"+rowKey.toArray()[i]);
								}
						
						catch(Throwable throwable) {
							flag= false;
									ReportGenerator.onTestFailure(throwable, "mandatoryCheck_"+rowKey.toArray()[i]);
								}
					}
					
					else {
						
						if(mandatory.equalsIgnoreCase("No")){
							if(true==Sucessflag)
								flag=true;
							
							 try {
									
									TestCasesResultWrite.writeData3(String.valueOf(flag), ToscanaConstant.SubModule_mandatory_check,String.valueOf(rowKey.toArray()[i]));
									
									
									}catch(Exception E) {
										E.printStackTrace();
									}

							
							try {
								Assert.assertEquals(true, Sucessflag);
								flag= true;
									ReportGenerator.onTestSuccess("mandatoryCheck_"+rowKey.toArray()[i]);
									}
							
							catch(Throwable throwable) {
								flag= false;
										ReportGenerator.onTestFailure(throwable, "mandatoryCheck"+rowKey.toArray()[i]);
									}
						}
				}
				
			
					
				}
				
				
		driver.navigate().refresh();
				
			}
	
			
		public static boolean isAlertPresent() 
		{ 
		    try 
		    { 
		    	
		           Alert Alert =   driver.switchTo().alert();	
	         	  String AlertText = Alert.getText();
	    
	         	 if(AlertText.contains(AlertTextContains))
		    	{
	         		Alert.accept(); 
		        driver.navigate().refresh();
		        return true; 
		        
		    	}
	         	 
	         	 else 
	         	 {
	         		 driver.navigate().refresh();
	         		 System.out.println("AlertText FOUND"+AlertText);
	         		 return false; 
	         	 }
		    	
		    }   
		    catch (Exception E) 
		    { 
		    	
		    	driver.navigate().refresh();
		        return false; 
		    }  
		    
		    
		}
			
@Override
public String getTestName() {
	
	return null;
}
}