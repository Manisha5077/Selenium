package TNApplication;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITest;
import org.testng.ITestContext;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.constant.ToscanaConstant;
import com.util.Utils;

import Resource.Base;

public class FieldLengthCheck  extends Base implements ITest {
	
	WebDriverWait wait = new WebDriverWait(driver,50);
	private ThreadLocal<String> testName = new ThreadLocal<>();
	static Map<String,List<String>> map=new HashMap<String,List<String>>();
	 static Map<String, List<String>> data=null;
	 static String saveXPath=null;

	 
	 @BeforeClass
		public void clean_test_result() {
			//logger.info("FormSubmission: Inside clean_test_result()");
			 try {
				   TestCasesResultWrite.clean_test_result_visibility(ToscanaConstant.SubModule_Length_check);
				
				   }catch(Exception E) {
					   //logger.error("FormSubmission: Inside clean_test_result(): error {}", E);
					   E.printStackTrace();
				   }
	 }
	 

static
	
	{ 
		
		try {

			data = ExcelVisibleRead.readExcel(System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"), prop.getProperty("xlsx.file.name"),
					prop.getProperty("enable.sheet.name"));
			saveXPath=	Utils.propertyfromxls("Savebutton");

		} catch (IOException e) {

		}
		
		for (Map.Entry<String, List<String>> mapData : data.entrySet()) {

			map.put(mapData.getKey(), mapData.getValue());

			
		}
		
		
	}

        @Test
		public void LengthCheck() {
        	
        	System.out.println("******************************************************INSIDE LENGTH CHECK*****************************************************");
        	
	boolean flag=false;

		for(int i=0;i<map.size();i++) {
			
			driver.navigate().refresh();
	
		try {
			
			List<String> mapList= map.get(data.keySet().toArray()[i]);//map.get(key), for sequence fix
			
			
			if(mapList.get(1).equalsIgnoreCase("input")) {
			
				
				if(mapList.get(5).equalsIgnoreCase("alphabet")) {

				
				GenericMethod.sendkeys(mapList.get(2), mapList.get(0), Length.RandomAlphabeticString());
				
				
				}
				
				else 
				
					if(mapList.get(5).equalsIgnoreCase("numeric"))
				{
					
					GenericMethod.sendkeys(mapList.get(2), mapList.get(0),String.valueOf(Length.RandomNumeric()) );
					
				}
				
					else
						
						if(mapList.get(5).equalsIgnoreCase("alphanumeric")) {
							
							GenericMethod.sendkeys(mapList.get(2), mapList.get(0),String.valueOf(Length.RandomAlphanumericString()) );
						}
				
				}
			WebElement element=GenericMethod.Find_element(mapList.get(2),mapList.get(0));

			
			int LengthAccepting=element.getAttribute("value").length();
	
			
			if((Double.valueOf(mapList.get(4))).intValue()==LengthAccepting) {
	
			flag=true;
			}
			else {
				
				flag=false;
			}
				
			 try {
					
					TestCasesResultWrite.writeData3(String.valueOf(flag), ToscanaConstant.SubModule_Length_check,String.valueOf(data.keySet().toArray()[i]));
					
					}catch(Exception E) {
						E.printStackTrace();
					}
			 
			 try {
					assertEquals(flag, true);
					flag= true;
						ReportGenerator.onTestSuccess("LengthCheck_"+data.keySet().toArray()[i]);
						}catch(Throwable throwable) {
							flag= false;
							ReportGenerator.onTestFailure(throwable, "LengthCheck_"+data.keySet().toArray()[i]);
						}
				
			
			
		}
			

		catch (Exception e) {
			
			System.out.println("e>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+e);
	
		}
		
		}
		
		}
	
		
		
	

	@Override
	public String getTestName() {
	
		return null;
	}
	
}
