package TNApplication;

public class Routing_map {

	
	String From_Queue;
	String Decision ;
	String To_Queue;
	
	public String getFrom_Queue() {
		return From_Queue;
	}
	public void setFrom_Queue(String from_Queue) {
		From_Queue = from_Queue;
	}
	public String getDecision() {
		return Decision;
	}
	public void setDecision(String decision) {
		Decision = decision;
	}
	public String getTo_Queue() {
		return To_Queue;
	}
	public void setTo_Queue(String to_Queue) {
		To_Queue = to_Queue;
	}
	
	
	
	@Override
	public String toString() {
		return "Routing_map [From_Queue=" + From_Queue + ", Decision=" + Decision + ", To_Queue=" + To_Queue + "]";
	}
	
	
}
