package TNApplication;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.awt.Window;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.constant.ToscanaConstant;

import Resource.Base;

public class DataLoss extends Base {

	WebDriverWait wait = new WebDriverWait(driver, 40);

	static Map<String, String> WIdata = null;
	static Map<String, String> Queues_detail_Data = null;
	static Map<String, String> Routing_Map_Data = null;
	static Map<String, List<String>> data = null;
	static Map<String, List<String>> data2 = null;
	Map<String, String> map = new HashMap<String, String>();

	@Test(priority = 1)
	public void DashboardPagelogin() {

		System.out.println("IN DashboardPagelogin");
		driver.get(super.propertyfromxls("dashboardurl"));

		logger.info("ToscanaLogin : inside DashboardPagelogin() method");

		driver.findElement(By.xpath(super.propertyfromxls("DashboardUsernameXPATH")))
				.sendKeys(super.propertyfromxls("dashusername"));
		driver.findElement(By.xpath(super.propertyfromxls("DashboardPasswordXPATH")))
				.sendKeys(super.propertyfromxls("dashpswrd"));
		driver.findElement(By.xpath(super.propertyfromxls("DashboardLoginBUTTON"))).click();

		logger.info("ToscanaLogin : Login successful");
		logger.info("ToscanaLogin : Application login smoke ran successfully");

		try {
			/*
			 * Assert.assertEquals(LengthAccepting>0, true); flag= true;
			 */
			ReportGenerator.onTestSuccess("DashboardPagelogin");
		} catch (Throwable throwable) {
			// flag= false;
			ReportGenerator.onTestFailure(throwable, "DashboardPagelogin");
		}

	}


	@Test(dataProvider = "WICreated-data-provider", dataProviderClass = DP.class, priority = 1)
	// @Test(priority = 2)
	public void Dataflow(String key, String Value) {
		
	// List<String> list	
		
		map.put(key, Value);
		
		
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		
		System.out.println("Value>>Value"+Value);

		System.out.println("IN DataFlow");
		

		try {

			data = ExcelVisibleRead.readExcelDataloss(
					System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"),
					prop.getProperty("xlsx.file.name"), prop.getProperty("DatalossCheck.sheet.name"),map.get(key));
			
		} catch (IOException e) {

		}

		try {

			Queues_detail_Data = ExcelVisibleRead.Queues_detail(
					System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"),
					prop.getProperty("xlsx.file.name"), prop.getProperty("Queues_detail_WISearch.sheet.name"));

		} catch (IOException e) {

		}
			
		try {
	
				for (Map.Entry<String, String> Queues_detail_Data_map : Queues_detail_Data.entrySet()) {
					
					System.out.println("Queues_detail_Data_map.getKey()>>>>>>>>>>>>>>"+Queues_detail_Data_map.getKey());
					
					System.out.println("map.get(key)>>>>>>>>>>>>>>"+map.get(key));
					
					if (map.get(key).equalsIgnoreCase(Queues_detail_Data_map.getKey())) {
						
						System.out.println("Queues_detail_Data_map.getValue()>>>>>>>"+Queues_detail_Data_map.getValue());
						
						driver.navigate().refresh();
						
						Thread.sleep(5000);
						
						driver.findElement(By.xpath((Queues_detail_Data_map.getValue()))).click();

						driver.findElement(By.xpath(super.propertyfromxls("SearchBox"))).click();

						driver.findElement(By.xpath(super.propertyfromxls("SearchBox"))).sendKeys(key);

						DataLoss DLC = new DataLoss();
						DLC.dataloss(Value);

					}
					
				}
		}
		
		catch(Exception E){
			E.printStackTrace();
		}
	
	}
						
	

	public void dataloss(String Value) {

		driver.findElement(By.xpath(
				"/html/body/div[1]/div/div/div/div[3]/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div/div[1]/table/tbody[1]/tr[2]/td[1]/a"))
				.click();

		String mainWindow = driver.getWindowHandle();
		Set<String> s = driver.getWindowHandles();
		Iterator<String> itr = s.iterator();
		while (itr.hasNext()) {
			String childWindow = itr.next();
//	    System.out.println("Window handle - > " + handle);
			if (!mainWindow.equals(childWindow)) {
				driver.switchTo().window(childWindow);
				//System.out.println(driver.switchTo().window(childWindow).getTitle());

			}
		}


		//System.out.println("data.get(\"Name\").get(0)>>>>>>>>>>>>>>>>>>)" + data.get("Name").get(0));

		//WebElement nameElement = GenericMethod.Find_element(data.get("Name").get(1), data.get("Name").get(0));// 1=locType,
																												// 0=xpathorid_value
      //WebElement WINumberElement= driver.findElement(By.xpath(super.propertyfromxls("WInumberXpath")));
		
		WebElement WINumberElement= driver.findElement(By.xpath("/html/body/form/div[1]/div[1]/div/div[1]/label[1]"));
      
		System.out.println("WINumberElement.getText()>>>>>>>>>>>>>"+WINumberElement.getText());
		
		if (WINumberElement != null) {
			// String nameValue=nameElement.getAttribute("value");

			//String WINumberValue = WINumberElement.getAttribute("value");
			
			String WINumberValue = WINumberElement.getText().replace("TASK NUMBER :", "").trim();

			System.out.println("WINumberValue>>>>>>>>>>>>>"+WINumberValue);
			
			try {

				data2 = ExcelData.readExcelInputData2(
						System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"),
						prop.getProperty("xlsx.file.name"), prop.getProperty("input.sheet.name"));

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}

			List<String> WINumberList = data2.get(WINumberValue);

			boolean flag = true;

			for (Entry<String, List<String>> dataset : data.entrySet()) {

				System.out.println("WINumberList>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + WINumberList);
				
				if (WINumberList == null) {
					flag = false;

					break;
				}

				List<String> datalist = dataset.getValue();
				String result=null;
				try {

					WebElement element = GenericMethod.Find_element(datalist.get(1), datalist.get(0));// 1=locType,
				    																					// 0=xpathorid_value
         if(datalist.get(3).equalsIgnoreCase("Y")) {		
                    
        	    if(datalist.get(4).equalsIgnoreCase("Y")) {
                    	
                    	if (element.isDisplayed()) {
    						System.out.println("As expected,element present in the queue");
    						System.out.println(element.getAttribute("value"));
    						result = element.getAttribute("value").replace("string:", "");
    						if (!WINumberList.contains(result)) {
    							flag = false;

    							break;
    						}
                           /*if (result.equalsIgnoreCase("")) {
                        	   flag = false;
                               
                        	   break;
                            }*/
                    	}else
                    	{
                    		System.out.println("Failed,element not present in the queue even though value is Y for current queue");
                    		flag = false;
                    		break;
                    	}
        	    }else if(datalist.get(4).equalsIgnoreCase("N")) {
        	    	if (!element.isDisplayed()) {
						System.out.println("As expected,element not present in the queue");
                	}else
                	{
                		System.out.println("Failed,element present in the queue even though value is N for current queue");
                		flag = false;
                		break;
                	}
        	    }
         }else if(datalist.get(3).equalsIgnoreCase("N")) {
        	 
        	          if(datalist.get(4).equalsIgnoreCase("Y")) {
        	        	  
        	        	     if(element.isDisplayed()) {
        	        	    	System.out.println("As expected,element present in the queue");
        	        	    	System.out.println(element.getAttribute("value"));
        						result = element.getAttribute("value").replace("string:", "");
        						if(result.equalsIgnoreCase("")) {
        							System.out.println("As expected,field is blank on current queue as field not present in Form Submission");
        							result=fillingAndCapturingExtraFields(dataset.getKey(),element,datalist.get(2),WINumberList.get(WINumberList.size()-1));
        						}else
        						{
        							System.out.println("Failed,field not blank on current queue even when field not present in Form Submission");
        						}
        	        	     }else
        	        	     {
        	        	    	 System.out.println("Failed,element not present in the current queue even though value is Y for current queue");
        	                	 flag = false;
        	                	 break;
        	        	     }
        	          }else if(datalist.get(4).equalsIgnoreCase("N")) {
        	        	  
        	        	  if(!element.isDisplayed()) {
      	        	    	System.out.println("As expected,element not present in the current queue");
        	        	  }else
      					 {
      							System.out.println("Failed,element present in the current queue even though value is N for current queue");
      							flag = false;
      							break;
      					 }
        	          }
         }
                    	
                        // assertEquals(result, true);

						// System.out.println("element>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+element);

						//System.out.println("result>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + result);

					     System.out.println("result>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+result);
					}
				    catch (Exception e) {
				    }
			}

			System.out.println("flag>>>>>>>>>>>>>>>>>>>>>>" + flag);
			
			try {
				Thread.sleep(6000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			driver.switchTo().window(mainWindow);

			
try {
				
				TestCasesResultWrite.writeData3(String.valueOf(flag), ToscanaConstant.SubModule_dataloss_check, Value);
				
				}catch(Exception E) {             
					E.printStackTrace();
				}
				
				
				try {
					assertEquals(flag, true);
					flag= true;
						ReportGenerator.onTestSuccess("DataLoss_"+Value);
						}catch(Throwable throwable) {
							flag= false;
							ReportGenerator.onTestFailure(throwable, "DataLoss_"+Value);
						}
		}

		
	}
	
	private void If(boolean b) {
		// TODO Auto-generated method stub
		
	}


	public String fillingAndCapturingExtraFields(String fieldName,WebElement element, String fieldDataType,String rowNumberToCapture) throws IOException {
		
		String filename=System.getProperty("user.dir")+prop.getProperty("xlsx.file.path");
		String sheetname=prop.getProperty("input.sheet.name");
		FileInputStream fis=new FileInputStream(filename);
		XSSFWorkbook wbookObj= new XSSFWorkbook(fis);
	    XSSFSheet sheetObj=wbookObj.getSheet(sheetname);
	    
		if(element.getTagName().equalsIgnoreCase("input")) {
			if(fieldDataType.equalsIgnoreCase("alphabet")) {
				element.sendKeys(Length.RandomAlphabeticString());
			}
			else if(fieldDataType.equalsIgnoreCase("Numeric")) {
				element.sendKeys(String.valueOf(Length.RandomNumeric()));
			}
			else if(fieldDataType.equalsIgnoreCase("alphanumeric")) {
				element.sendKeys(String.valueOf(Length.RandomAlphanumericString()));
			}
		}
		else if(element.getTagName().equalsIgnoreCase("select")) {
			if(fieldDataType.equalsIgnoreCase("DD")) {
				Select dropdown = new Select(element);
				List<WebElement> weblist=dropdown.getOptions();
				int iCnt=weblist.size();
				Random num=new Random();
				int iSelect=num.nextInt(iCnt);
				dropdown.selectByIndex(iSelect);
			}
		}
		else if(element.getTagName().equalsIgnoreCase("textarea")) {
			if(fieldDataType.equalsIgnoreCase("alphabet")) {
				element.sendKeys(Length.RandomAlphabeticString());
			}
			else if(fieldDataType.equalsIgnoreCase("Numeric")) {
				element.sendKeys(String.valueOf(Length.RandomNumeric()));
			}
			else if(fieldDataType.equalsIgnoreCase("alphanumeric")) {
				element.sendKeys(String.valueOf(Length.RandomAlphanumericString()));
			}
		}
		
		String capturedValue= element.getAttribute("value");
		int fieldCellNumber=GenericMethod.fetchingCellNumberForColumnHeadersInExcel(sheetObj,fieldName);
		int rowNumber=Integer.parseInt(rowNumberToCapture);
		sheetObj.getRow(rowNumber).getCell(fieldCellNumber).setCellValue(capturedValue);
		FileOutputStream fileOut=new FileOutputStream(filename);
		wbookObj.write(fileOut);
		wbookObj.close();
		driver.findElement(By.xpath(super.propertyfromxls("Savebutton"))).click();
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return capturedValue;
	}
	
	
	public void dataloss2() {

		driver.findElement(By.xpath(
				"/html/body/div[1]/div/div/div/div[3]/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div/div[1]/table/tbody[1]/tr[2]/td[1]/a"))
				.click();

		String mainWindow = driver.getWindowHandle();
		Set<String> s = driver.getWindowHandles();
		Iterator<String> itr = s.iterator();
		while (itr.hasNext()) {
			String childWindow = itr.next();
//	    System.out.println("Window handle - > " + handle);
			if (!mainWindow.equals(childWindow)) {
				driver.switchTo().window(childWindow);
				//System.out.println(driver.switchTo().window(childWindow).getTitle());

			}
		}


		//System.out.println("data.get(\"Name\").get(0)>>>>>>>>>>>>>>>>>>)" + data.get("Name").get(0));

		WebElement nameElement = GenericMethod.Find_element(data.get("Name").get(1), data.get("Name").get(0));// 1=locType,
																												// 0=xpathorid_value

		if (nameElement != null) {
			// String nameValue=nameElement.getAttribute("value");

			String nameValue = nameElement.getAttribute("value");

			try {

				data2 = ExcelData.readExcelInputData2(
						System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"),
						prop.getProperty("xlsx.file.name"), prop.getProperty("input.sheet.name"));

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}

			List<String> Namelist = data2.get(nameValue);

			boolean flag = true;

			for (Entry<String, List<String>> dataset : data.entrySet()) {

				//System.out.println("Namelist_Q1>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + Namelist);

				List<String> datalist = dataset.getValue();
				try {

					WebElement element = GenericMethod.Find_element(datalist.get(1), datalist.get(0));// 1=locType,
																										// 0=xpathorid_value

					if (element != null) {
						String result = element.getAttribute("value").replace("string:", "");

						// assertEquals(result, true);

						// System.out.println("element>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+element);

						//System.out.println("result>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + result);

						if (Namelist == null) {
							flag = false;

							break;
						}

						if (!Namelist.contains(result)) {
							flag = false;

							break;
						}

						 System.out.println("result>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+result);
					}
				} catch (Exception e) {
				}
			}

			System.out.println("flag>>>>>>>>>>>>>>>>>>>>>>" + flag);
			
			try {
				Thread.sleep(6000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			driver.switchTo().window(mainWindow);
			
		}
		
	}
	
public void dataloss3() {
		
		System.out.println("Inside DATALOSS33333333333333333333333333333333333333333333333333333333");

		driver.findElement(By.xpath(
				"/html/body/div[1]/div/div/div/div[3]/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div/div[1]/table/tbody[1]/tr[2]/td[1]/a"))
				.click();

		String mainWindow = driver.getWindowHandle();
		Set<String> s = driver.getWindowHandles();
		Iterator<String> itr = s.iterator();
		while (itr.hasNext()) {
			String childWindow = itr.next();
//	    System.out.println("Window handle - > " + handle);
			if (!mainWindow.equals(childWindow)) {
				driver.switchTo().window(childWindow);
				//System.out.println(driver.switchTo().window(childWindow).getTitle());

			}
		}


		//System.out.println("data.get(\"Name\").get(0)>>>>>>>>>>>>>>>>>>)" + data.get("Name").get(0));

		//WebElement nameElement = GenericMethod.Find_element(data.get("Name").get(1), data.get("Name").get(0));// 1=locType,
																												// 0=xpathorid_value
      //WebElement WINumberElement= driver.findElement(By.xpath(super.propertyfromxls("WInumberXpath")));
		
		WebElement WINumberElement= driver.findElement(By.xpath("/html/body/form/div[1]/div[1]/div/div[1]/label[1]"));//xpath of header WInumber
      
		System.out.println("WINumberElement.getText()>>>>>>>>>>>>>"+WINumberElement.getText());
		
		if (WINumberElement != null) {
			// String nameValue=nameElement.getAttribute("value");

			//String WINumberValue = WINumberElement.getAttribute("value");
			
			String WINumberValue = WINumberElement.getText().replace("TASK NUMBER :", "").trim();

			System.out.println("WINumberValue>>>>>>>>>>>>>"+WINumberValue);
			
			try {

				data2 = ExcelData.readExcelInputData2(
						System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"),
						prop.getProperty("xlsx.file.name"), prop.getProperty("input.sheet.name"));

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}

			List<String> WINumberList = data2.get(WINumberValue);

			boolean flag = true;

			for (Entry<String, List<String>> dataset : data.entrySet()) {

				System.out.println("WINumberList>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + WINumberList);

				List<String> datalist = dataset.getValue();
				try {

					WebElement element = GenericMethod.Find_element(datalist.get(1), datalist.get(0));// 1=locType,
																										// 0=xpathorid_value

					if (element != null) {
						String result = element.getAttribute("value").replace("string:", "");

						// assertEquals(result, true);

						// System.out.println("element>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+element);

						//System.out.println("result>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + result);

						if (WINumberList == null) {
							flag = false;

							break;
						}

						if (!WINumberList.contains(result)) {
							flag = false;

							break;
						}

						 System.out.println("result>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+result);
					}
				} catch (Exception e) {
				}
			}

			System.out.println("flag>>>>>>>>>>>>>>>>>>>>>>" + flag);
			
			try {
				Thread.sleep(6000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			driver.switchTo().window(mainWindow);

		}
	
}


	
}
