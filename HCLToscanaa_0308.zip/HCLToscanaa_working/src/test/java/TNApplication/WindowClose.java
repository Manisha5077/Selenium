package TNApplication;

import org.testng.annotations.Test;

import Resource.Base;

public class WindowClose extends Base{


	@Test (priority=1)
	public void Closewindow() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.quit();
	}
	/*
	@Test(priority=2)
	public void testCloseWindow() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.close();*/
	}

