package TNApplication;

	import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;
import java.util.List;
import java.util.Map;

import org.testng.annotations.AfterTest;
	import org.testng.annotations.BeforeTest;
	import org.testng.annotations.Test;

import com.util.Utils;

import Resource.Base;

	
	public class JdbcConnection extends Base {
	
	/*@Test
	public static void getdatabaseConnectionAndExtractIntoExcel() throws Exception {
		
		String url=Utils.propertyfromxls("DatabaseURL");
		String username=Utils.propertyfromxls("DatabaseUsername");
		String password=Utils.propertyfromxls("DatabasePassword");
		String sqlquery=Utils.propertyfromxls("SQLQuery");
		String columnHeadersCelltxt=Utils.propertyfromxls("DatabaseOutputExtract_ColumnHeadersInExcel");
		String parametersNameCelltxt=Utils.propertyfromxls("ParameterNamesinDatabase");
		Connection connection=GenericMethod.performingDatabaseConnection(url, username, password);
		List<String> columnHeaderNamesList=GenericMethod.valueExtractionFromCombinedCelltxt(columnHeadersCelltxt);
		List<String> parametersNameList=GenericMethod.valueExtractionFromCombinedCelltxt(parametersNameCelltxt);    
		GenericMethod.fetchingdataFromDatabaseAndCopyingintoExcel(connection, sqlquery,parametersNameList,columnHeaderNamesList);
		
}*/
		
		/*@Test
		public static void getdatabaseConnectionAndExtractIntoExcel() throws Exception {
			
			String url=Utils.propertyfromxls("DatabaseURL");
			String username=Utils.propertyfromxls("DatabaseUsername");
			String password=Utils.propertyfromxls("DatabasePassword");
			//String sqlquery=Utils.propertyfromxls("SQLQuery");
			
			Map<String, String> queriesmap = ExcelVisibleRead.queries(System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"),
					prop.getProperty("xlsx.file.name"), prop.getProperty("SQLQueries.sheet.name"));
			
			String query = queriesmap.get("SQLQuery");
			
			String columnHeadersCelltxt=Utils.propertyfromxls("DatabaseOutputExtract_ColumnHeadersInExcel");
			String parametersNameCelltxt=Utils.propertyfromxls("ParameterNamesinDatabase");
			Connection connection=GenericMethod.performingDatabaseConnection(url, username, password);
			List<String> columnHeaderNamesList=GenericMethod.valueExtractionFromCombinedCelltxt(columnHeadersCelltxt);
			List<String> parametersNameList=GenericMethod.valueExtractionFromCombinedCelltxt(parametersNameCelltxt);    
			GenericMethod.fetchingdataFromDatabaseAndCopyingintoExcel(connection, query,parametersNameList,columnHeaderNamesList);
		
			
			
	}*/
		
}

