package TNApplication;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.constant.ToscanaConstant;

import Resource.Base;

public class GenericMethod extends Base {

	public static WebElement Find_element(String locator_type, String Locator_value) {
		WebElement element = null;
		if (locator_type.equalsIgnoreCase("id")) {

			try {
				element = driver.findElement(By.id(Locator_value));
			}

			catch (Exception e) {
			}
		} else if (locator_type.equalsIgnoreCase("xpath")) {
			try {
				element = driver.findElement(By.xpath(Locator_value));
			}
			catch (Exception e) {

			}
		}
		return element;
	}

	public static void closeexcel(Workbook myWorkbook) {

		try {
			if (myWorkbook != null)
				myWorkbook.close();
			logger.info("Clossing excel");

		} catch (IOException e) {
			logger.error("Clossing excel ", e);
		}
	}

	public static void Writeexcel(int row_counter, String toscana_constants, XSSFSheet result_sheet,
			String field_name) {
		Row row = result_sheet.createRow(row_counter);
		Cell cell_name = row.createCell(0);
		cell_name.setCellValue(field_name);
		Cell cell_result = row.createCell(1);
		cell_result.setCellValue(toscana_constants);
	}

	public static void sendkeys(String locator_type, String Locator_value, String KeysToSend) {
		WebElement element = null;
		if (locator_type.equalsIgnoreCase("id")) {
			element = driver.findElement((By.id(Locator_value)));
			element.sendKeys(KeysToSend);

		} else if (locator_type.equalsIgnoreCase("xpath")) {

			element = driver.findElement((By.xpath(Locator_value)));
			element.sendKeys(KeysToSend);
		}
	}

	public static void sendkeys_To_dropdown(String locator_type, String Locator_value, String KeysToSend) {
		WebElement element = null;
		if (locator_type.equalsIgnoreCase("id")) {

			element = driver.findElement((By.id(Locator_value)));

			Select dropdown = new Select(element);

			dropdown.selectByVisibleText(KeysToSend);

		} else if (locator_type.equalsIgnoreCase("xpath")) {
			element = driver.findElement((By.xpath(Locator_value)));
			// element.sendKeys(KeysToSend);
			Select dropdown = new Select(element);
			dropdown.selectByVisibleText(KeysToSend);
		}

	}

	public static boolean returntrue(boolean flag1, boolean flag2, boolean flag3) {

		if (flag1 && flag2 && flag3) {

			return true;
		} else {

			return false;
		}

		// return (flag1 && flag2 && flag3);

	}
	
public static Connection performingDatabaseConnection(String url,String databaseUsername, String databasePassword) {
		
		Connection connection=null;
		try {
			connection=DriverManager.getConnection(url, databaseUsername, databasePassword);
			System.out.println("Connected to Microsoft SQL Server");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Oops, there's an error");
			e.printStackTrace();
		}
		
		return connection;
	}
	
public static List<String> valueExtractionFromCombinedCelltxt(String combinedCelltxt) {
	
	String[] columnHeaderNames=combinedCelltxt.split(";");
	List<String> columnHeaderNamesList=Arrays.asList(columnHeaderNames);
	return columnHeaderNamesList;
	
}


public static int fetchingCellNumberForColumnHeadersInExcel(Sheet mysheet,String columnHeaderName) throws IOException{
	int i=0;
    XSSFRow rowHeader=(XSSFRow) mysheet.getRow(0);
    
    for(i=1;i<=rowHeader.getLastCellNum();i++) {
    	if(rowHeader.getCell(i-1).getStringCellValue().trim().equalsIgnoreCase(columnHeaderName.trim())) {
    		break;
    	}
    }
	return (i-1);
}




/*public static void DatabaseWIDetails() {
	
	Map<List<String>, List<String>> dataMap = new LinkedHashMap();
	
	List<String> lt1 = new ArrayList();
	lt1.addAll(parameter1Value)
	
	List<String> lt2 = new ArrayList();
	
	
	
}*/






public static void deletingExistingDatabaseExtract_OutputSheet(String filename,String sheetname) throws IOException{
	
	FileInputStream fis=new FileInputStream(filename);
	XSSFWorkbook wbookobj=new XSSFWorkbook(fis);
	int indexNo=wbookobj.getSheetIndex(sheetname);
	wbookobj.removeSheetAt(indexNo);
	FileOutputStream fout=new FileOutputStream(filename);
	wbookobj.write(fout);
	wbookobj.close();
}

public static void writeWIinRouteExcel(int number) {
	
	
	
	
}

}

