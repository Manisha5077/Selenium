package TNApplication;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import Resource.Base;

public class DashboardLogin extends Base{

	@Test(priority = 1)
	public void DashboardPagelogin() {

		System.out.println("\"******************************************************INSIDE DASHBOARDPAGE LOGIN*****************************************************");
		
		driver.get(super.propertyfromxls("dashboardurl"));

		logger.info("ToscanaLogin : inside DashboardPagelogin() method");

		driver.findElement(By.xpath(super.propertyfromxls("DashboardUsernameXPATH")))
				.sendKeys(super.propertyfromxls("dashusername"));
		
		
		System.out.println("Before Login Page title is : " + driver.getTitle());
		
		
		System.out.println("dashusername"+super.propertyfromxls("dashusername"));
		driver.findElement(By.xpath(super.propertyfromxls("DashboardPasswordXPATH")))
				.sendKeys(super.propertyfromxls("dashpswrd"));
		driver.findElement(By.xpath(super.propertyfromxls("DashboardLoginBUTTON"))).click();

		logger.info("ToscanaLogin : Login successful");
		logger.info("ToscanaLogin : Application login smoke ran successfully");
		
		System.out.println("After clicking on Login : Page title is : " + driver.getTitle());

		try {
			
			ReportGenerator.onTestSuccess("DashboardPagelogin");
		} catch (Throwable throwable) {
			
			ReportGenerator.onTestFailure(throwable, "DashboardPagelogin");
		}

	}
	
	
}
