package TNApplication;

import org.testng.TestListenerAdapter;
import org.testng.TestNG;

public class MainClass {

	public static void main(String[] args) {
		
		
		System.out.println("Toscana Automtion started!!!!!!");
		System.out.println(System.getProperty("user.dir"));
		//TestListenerAdapter testla = new TestListenerAdapter();
		TestNG testng = new TestNG();
		testng.setTestClasses(new Class[] {ToscanaLogin.class,FieldVisibility.class,MandatoryCheck.class,EnableCheck.class,
				FormSubmission.class,FieldLengthCheck.class,FieldDataTypeCheck.class,DashboardLogin.class,
				WISearch.class,DataLoss.class,WindowClose.class});
		testng.run();
		
	}

}
