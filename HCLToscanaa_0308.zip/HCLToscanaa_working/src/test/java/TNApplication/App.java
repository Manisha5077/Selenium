package TNApplication;

import org.testng.TestListenerAdapter;
import org.testng.TestNG;

public class App {

	
	
	public static void main( String[] args) {
		
	
	System.out.println("Toscana Automtion started!!!!!!");
	System.out.println(System.getProperty("user.dir"));
	/*try {
		//JdbcConnection_ori.getdatabaseConnection();
		
		JdbcConnection2.getdatabaseConnectionAndExtractIntoExcel();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}*/
	
	/*try {
		
		JdbcConnection.getdatabaseConnectionAndExtractIntoExcel();
		
	}
	catch(Exception E) {
		E.printStackTrace();
	}*/
	
		
		//TestListenerAdapter test = new TestListenerAdapter();
		TestNG testng = new TestNG();
		//testng.setTestClasses(new Class[] {ToscanaLogin.class});
		//testng.setTestClasses(new Class[] {ToscanaLogin.class,VisibilityCheck.class,MandatoryCheck4.class,FormSubmission.class,LengthCheck.class,DataTypeCheck.class,DataLossCheck5.class,JdbcConnection.class,SearchWI.class});
		
		//testng.setTestClasses(new Class[] {ToscanaLogin.class,FormSubmission.class,JdbcConnection.class,SearchWI.class});
				
				//FormSubmission.class,JdbcConnection.class,SearchWI2.class});
		
		testng.setTestClasses(new Class[] {JdbcConnection.class,WISearch.class,DataLoss.class,RoutingCheck.class});
				
				//RouteNextLevel5.class});
		//,DataLossCheck5.class, RouteNextLevel5.class
		
		testng.run();
		
	
	}
}
