package TNApplication;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.collections.Lists;

import Resource.Base;

public class DP extends Base {

	Map<String, String> WIdata = null;
	Map<String, List<String>> data = null;
	Map<List<String>, List<String>> data2 = null;
	Map<String, List<String>> data3 = null;
	Map<String, String> databaseData = new LinkedHashMap<String,String>();
	
	@DataProvider(name = "visible-data-provider")
	public Object[][] dpMethod() {
  //reading excel
		try {

			data = ExcelVisibleRead.readExcelVisible(
					System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"),
					prop.getProperty("xlsx.file.name"), prop.getProperty("visible.sheet.name"));

			//System.out.println("data>>>>>>>>>>>>>>>>"+data);
			
		} catch (IOException e) {

		}

		//setting data in two D array
		int length = data.size();
		Object[][] obj = new Object[length][2];

		int i = 0;
		for (Map.Entry<String, List<String>> map : data.entrySet()) {

			obj[i][0] = map.getKey();

			obj[i][1] = map.getValue();
			i++;
		}

		return obj;
	}

	@DataProvider(name = "enable-data-provider")
	public Object[][] dpMethod_enable() {
  //reading excel
		try {

			data = ExcelVisibleRead.readExcel(System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"), prop.getProperty("xlsx.file.name"),
					prop.getProperty("enable.sheet.name"));

		} catch (IOException e) {

		}

		//setting data in two D array
		int length = data.size();
		Object[][] obj = new Object[length][2];

		int i = 0;
		for (Map.Entry<String, List<String>> map : data.entrySet()) {

			obj[i][0] = map.getKey();

			obj[i][1] = map.getValue();
			i++;
		}

		return obj;
	}
	
	/*public Object[][] dpMethod_enable2() {
		  //reading excel
				try {

					data = ExcelVisibleRead.readExcel(System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"), prop.getProperty("xlsx.file.name"),
							prop.getProperty("enable.sheet.name"));

				} catch (IOException e) {

				}

				//setting data in two D array
				int length = data.size();
				Object[][] obj = new Object[length][2];

				int i = 0;
				for (Map.Entry<String, List<String>> map : data.entrySet()) {

					obj[i][0] = map.getKey();

					obj[i][1] = map.getValue();
					i++;
					
				}

				return obj;
			}
			*/
	
	
	@DataProvider(name = "input-data-provider")
	public static Object[][] dpMethod_input() {
  //reading excel
		System.out.println("DP>>INPUT>>>>>>>>>>>>>>>>");
		
		Map<String, List<String>> data2 = null;
		try {

			data2 = ExcelVisibleRead.readExcelInputData2(System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"), prop.getProperty("xlsx.file.name"),
					prop.getProperty("input.sheet.name"));
			
			System.out.println("data2>>>>>>>>>>>>>"+data2);

		} catch (IOException e) {

		}
		//setting data in two D array
		int length = data2.size();

		Object[][] obj = new Object[length][2];

		int i = 0;
		for (Map.Entry<String, List<String>> map : data2.entrySet()) {

			System.out.println("DP>>>>>>>>>>>>>>>>>>>>>>>>>>>>value  of i "+i);
			obj[i][0] = map.getKey();

			obj[i][1] = map.getValue();
			i++;
			}

		return obj;
	}
	
	@DataProvider(name = "Mandatory-data-provider")
	public Object[][] dpMethod_Mandatory() {
		Map<String, Map<List<String>, List<String>>> data2 = null;
		try {

			data2 = ExcelVisibleRead.readMandatoryData(
					System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"),
					prop.getProperty("xlsx.file.name"), prop.getProperty("Mandatory.sheet.name"));

		} catch (IOException e) {

		}

		int length = data2.size();
		Object[][] obj = new Object[length][2];

		int i = 0;
		for (Map.Entry<String, Map<List<String>, List<String>>> map : data2.entrySet()) {

			obj[i][0] = map.getKey();
			obj[i][1] = map.getValue();
			i++;

		}

		return obj;
	}
	
	
	/*@DataProvider(name = "Dataloss-data-provider")
	public Object[][] dpMethod_Dataloss() {
  //reading excel
		try {

			data = ExcelVisibleRead.readExcelDataloss(
					System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"),
					prop.getProperty("xlsx.file.name"), prop.getProperty("DatalossCheck.sheet.name"));

			//System.out.println("data>>>>>>>>>>>>>>>>"+data);
			
		} catch (IOException e) {

		}

		//setting data in two D array
		int length = data.size();
		Object[][] obj = new Object[length][2];

		int i = 0;
		for (Map.Entry<String, List<String>> map : data.entrySet()) {

			obj[i][0] = map.getKey();

			obj[i][1] = map.getValue();
			i++;
		}

		return obj;
	}*/
	
	
	@DataProvider(name = "WICreated-data-provider")
	public Object[][] WICreateddpMethod() {
  //reading excel
		try {

			WIdata = ExcelVisibleRead.readExcelWICreated();
			
			/*		System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"),
					prop.getProperty("xlsx.file.name"), prop.getProperty("DatabaseExtract.sheet.name"));*/

			System.out.println("WIdata_SHOWING WI CREATED DATA>>>>>>>>>>>>>>>>"+WIdata);
			
		} catch (IOException e) {

		}

		int length = WIdata.size();
		Object[][] obj = new Object[length][2];

		int i = 0;
		for (Entry<String, String> map : WIdata.entrySet()) {

			obj[i][0] = map.getKey();
			obj[i][1] = map.getValue();
			i++;

			
			System.out.println("map.getKey()========================="+map.getKey());
			
			System.out.println("map.getValue()========================="+map.getValue());
			
	
		}
		
		System.out.println("obj========================="+obj);

		return obj;
	}
	
	
	@DataProvider(name = "Database-data-provider")
	public Object[][] fetchingdataFromDatabaseAndSearchingIntoApplication() throws Exception {
		String url=super.propertyfromxls("DatabaseURL");
		String username=super.propertyfromxls("DatabaseUsername");
		String password=super.propertyfromxls("DatabasePassword");
		Map<String, String> queriesmap = ExcelVisibleRead.queries(System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"),
				prop.getProperty("xlsx.file.name"), prop.getProperty("SQLQueries.sheet.name"));
		String query = queriesmap.get("SQLQuery");
		
		String columnHeadersCelltxt=super.propertyfromxls("DatabaseOutputExtract_ColumnHeadersInExcel");
		String parametersNameCelltxt=super.propertyfromxls("ParameterNamesinDatabase");
		Connection connection=GenericMethod.performingDatabaseConnection(url, username, password);
		
		List<String> columnHeaderNamesList=GenericMethod.valueExtractionFromCombinedCelltxt(columnHeadersCelltxt);
		List<String> parametersNameList=GenericMethod.valueExtractionFromCombinedCelltxt(parametersNameCelltxt);
		
		String filename=System.getProperty("user.dir")+prop.getProperty("xlsx.file.path");
	    String sheetname=prop.getProperty("DatabaseExtract.sheet.name");
	    GenericMethod.deletingExistingDatabaseExtract_OutputSheet(filename, sheetname);
	    Statement statement=connection.createStatement();
		ResultSet result=statement.executeQuery(query);
		OutputInExcel.wi_WriteInExcelSearchResult(columnHeaderNamesList);
		while(result.next()) {
			String parameter1Value=result.getString(parametersNameList.get(0).trim());
			System.out.println("Parameter1Value: "+parameter1Value);
			String parameter2Value=result.getString(parametersNameList.get(1).trim());
			System.out.println("Parameter2Value: "+parameter2Value);
			/*for (String parameterName : parametersNameList) {
				result.getString(parameterName.trim());
			}*/
			databaseData.put(parameter1Value, parameter2Value);
		}
        
		int length = databaseData.size();
		Object[][] obj = new Object[length][2];

		int i = 0;
		for (Entry<String, String> databaseRecord : databaseData.entrySet()) {

			obj[i][0] = databaseRecord.getKey();
			obj[i][1] = databaseRecord.getValue();
			i++;

		}
	   connection.close();
	return obj;
	}


	
	
	/*@DataProvider(name = "Length-data-provider")
	public Object[][] dpMethod_Length() {
  //reading excel
		Map<String, List<String>> data3 = null;
		try {
			
			
			data3 = ExcelVisibleRead.readExcelLengthData(System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"), prop.getProperty("xlsx.file.name"),
					prop.getProperty("Length.sheet.name"));

		} catch (IOException e) {

		}

		//setting data in two D array
		//System.out.println("DP_Length-data-provider>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		
		int length = data3.size();
		Object[][] obj = new Object[length][2];

		int i = 0;
		for (Map.Entry<String, List<String>> map : data3.entrySet()) {

			//System.out.println("value  of i "+i);
			obj[i][0] = map.getKey();

			obj[i][1] = map.getValue();
			i++;
			
			//System.out.println("map.getKey()>>>>>>>>>>>>>>>>>>>>>>"+map.getKey());
			//System.out.println("map.getValue()>>>>>>>>>>>>>>>>>>>>>>"+map.getValue());
			
			//System.out.println("map.getValue()>>>>>>>>>>>>>>>>>input>>>>>>>>>>>>>>"+map.getValue());
			
			
		
		}
		return obj;*/
		
	/*@DataProvider(name = "input-data-provider2")
	public Object[][] dpMethod_input2() {
  //reading excel
		
		try {
			
			data2 = ExcelVisibleRead.readExcelInputData2(System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"), prop.getProperty("xlsx.file.name"),
					prop.getProperty("input.sheet.name"));

		} catch (IOException e) {

		}

		//setting data in two D array
		int length = data2.size();
		System.out.println("data2 size in dataprovider2  >>>>>>>>"+data2.size());
		
		
		Object[][] obj = new Object[length][2];

		int i = 0;
		for (Map.Entry<List<String>, List<String>> map : data2.entrySet()) {

			
			obj[i][0] = map.getKey();

			obj[i][1] = map.getValue();
			i++;
			
			System.out.println("mp.getkey data provider2 >>>>>>>>>>"+map.getKey()+"map.getValue()    data provider2 >>>>>>>>>>>>>>>>>input>>>>>>>>>>>>>>"+map.getValue());
			
			
			
		
		}
		
		List<Object[]> result = Lists.newArrayList();
		  result.addAll(Arrays.asList(dpMethod_enable2()));
		  result.add(obj);
		  return result.toArray(new Object[result.size()][]);
		return obj;
	}
*/
	
	
}

