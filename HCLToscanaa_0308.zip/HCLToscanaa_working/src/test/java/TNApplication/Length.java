package TNApplication;

import java.util.Random;

import org.testng.annotations.Test;

public class Length {
	
	
	public  static String RandomAlphabeticString() {
	    int leftLimit = 97; // letter 'a'
	    int rightLimit = 122; // letter 'z'
	 int targetStringLength = 100;
	    Random random = new Random();

	    String generatedString = random.ints(leftLimit, rightLimit + 1)
	      .limit(targetStringLength)
	      .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
	      .toString();

	   System.out.println("alphabet>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+generatedString);
	    
	   return generatedString;
	}
	
	
	
	public static  String  RandomAlphanumericString() {
	    int leftLimit = 48; // numeral '0'
	    int rightLimit = 122; // letter 'z'
	  int targetStringLength = 100;
	    //int targetStringLength;
	    Random random = new Random();

	    String generatedString = random.ints(leftLimit, rightLimit + 1)
	      //.filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
	      .limit(targetStringLength)
	      .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
	      .toString();

	   System.out.println("alphanumeric>>>>>>>>>>>>>>>>>>>>>>>"+generatedString);
	    
	    return generatedString;
	}


	 public static long RandomNumeric() {
	      Random rand = new Random(); //instance of random class
	      int lowerbound =10000;
	      int upperbound =99999; 
	        //generate random values from 0-24

	        //Random rand = new Random(seed);
	      
	int random_integer = rand.nextInt(upperbound-lowerbound) + lowerbound;
	    long data= random_integer+1000000000;
	      

	     
	      System.out.println("NUMERIC>>>>>>>>>>>>>>>>>>>>>"+data);
	    
	 return data;
	}
	
  
	 public static  String  RandomSymbolString() {
		    int leftLimit = 32; // numeral '0'
		    int rightLimit = 47; // letter 'z'
		  int targetStringLength = 100;
		    //int targetStringLength;
		    Random random = new Random();

		    String generatedString = random.ints(leftLimit, rightLimit + 1)
		      //.filter(i -> (i >= 32) && i <= 47) //&& (i >= 58 || i <= 64))
		      .limit(targetStringLength)
		      .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
		      .toString();

		  System.out.println("SYMBOLS>>>>>>>>>>>>>>>>>>>>>>>"+generatedString);
		    
		    return generatedString;
		}
	 
}
