package TNApplication;

import java.io.File;

import java.io.FileInputStream;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Predicate;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;

import org.apache.poi.ss.usermodel.Sheet;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.util.Utils;

//import com.nesterovskyBros.annotation.Yield;

import Resource.Base;

class ExcelVisibleRead extends Base{

	static Map<List<String>, List<String>> WIdata = null;
	
	
	
	public static Map<String, List<String>> readExcel(String filePath, String fileName, String sheetName)
			throws IOException {

		int p = 1;
		// Create an object of File class to open xlsx file

		File file = new File(filePath + "\\" + fileName);

		// Create an object of FileInputStream class to read excel file

		FileInputStream inputStream = new FileInputStream(file);

		Workbook myWorkbook = null;

		// Find the file extension by splitting file name in substring and getting only
		// extension name

		String fileExtensionName = fileName.substring(fileName.indexOf("."));

		// Check condition if the file is xlsx file

		if (fileExtensionName.equals(".xlsx")) {

			// If it is xlsx file then create object of XSSFWorkbook class

			myWorkbook = new XSSFWorkbook(inputStream);

		}

		// Check condition if the file is xls file

		else if (fileExtensionName.equals(".xls")) {

			// If it is xls file then create object of HSSFWorkbook class

			myWorkbook = new HSSFWorkbook(inputStream);

		}

		// Read sheet inside the workbook by its name

		Sheet mysheet = myWorkbook.getSheet(sheetName);
		System.out.println("sheetName" + sheetName);
		// Find number of rows in excel file
		int rowCount = mysheet.getLastRowNum() - mysheet.getFirstRowNum();

		System.out.println("rowCount   " + rowCount);

		Map<String, List<String>> dataMap = new LinkedHashMap();

		Row row1 = mysheet.getRow(0);

		for (p = 1; p <= rowCount; p++) {

			Row row = mysheet.getRow(p);

			if (row.getCell(1).getStringCellValue() != null && !row.getCell(1).getStringCellValue().equals("")) {

				List<String> lt = new ArrayList();

				lt.add(row.getCell(1).getStringCellValue());// 0//id value
				lt.add(row.getCell(3).getStringCellValue());// 1//input /dd
				lt.add(row1.getCell(1).getStringCellValue());// index 2//id
				lt.add(row.getCell(4).getStringCellValue());// MandatoryCheck
				lt.add(String.valueOf(row.getCell(5).getNumericCellValue()));// Length
				lt.add(row.getCell(6).getStringCellValue());// datatype
				dataMap.put(row.getCell(0).getStringCellValue(), lt);
			} else {
				List<String> lt = new ArrayList();

				lt.add(row.getCell(2).getStringCellValue());
				lt.add(row.getCell(3).getStringCellValue());
				lt.add(row1.getCell(2).getStringCellValue());
				lt.add(row.getCell(4).getStringCellValue());
				lt.add(String.valueOf(row.getCell(5).getNumericCellValue()));
				lt.add(row.getCell(6).getStringCellValue());// datatype
				dataMap.put(row.getCell(0).getStringCellValue(), lt);
			}
		}
		// GenericMethod.closeexcel(myWorkbook);
		return dataMap;

	}

	public static Map<String, List<String>> readExcelVisible(String filePath, String fileName, String sheetName)
			throws IOException {
		int p = 1;
		File file = new File(filePath + "\\" + fileName);
		FileInputStream inputStream = new FileInputStream(file);
		Workbook myWorkbook = null;
		String fileExtensionName = fileName.substring(fileName.indexOf("."));
		if (fileExtensionName.equals(".xlsx")) {
			myWorkbook = new XSSFWorkbook(inputStream);
		} else if (fileExtensionName.equals(".xls")) {
			myWorkbook = new HSSFWorkbook(inputStream);
		}
		Sheet mysheet = myWorkbook.getSheet(sheetName);
		System.out.println("sheetName" + sheetName);
		int rowCount = mysheet.getLastRowNum() - mysheet.getFirstRowNum();

		Map<String, List<String>> dataMap = new LinkedHashMap();
		for (p = 1; p <= rowCount; p++) {

			Row row = mysheet.getRow(p);
			if (row.getCell(1).getStringCellValue() != null && !row.getCell(1).getStringCellValue().equals("")) {
				List<String> lt = new ArrayList();

				lt.add(row.getCell(1).getStringCellValue());// 0
				lt.add("id");// 1
				lt.add(String.valueOf(p));// 2
				dataMap.put(row.getCell(0).getStringCellValue(), lt);
			} else {
				List<String> lt = new ArrayList();
				lt.add(row.getCell(2).getStringCellValue());// 0
				lt.add("xpath");// 1
				lt.add(String.valueOf(p));// 2
				dataMap.put(row.getCell(0).getStringCellValue(), lt);
			}
		}
		GenericMethod.closeexcel(myWorkbook);
		return dataMap;
	}

	/*
	 * public static Map <String,List<String>> readExcelInputData(String
	 * filePath,String fileName,String sheetName) throws IOException{
	 * 
	 * int p=1; //Create an object of File class to open xlsx file
	 * 
	 * File file = new File(filePath+"\\"+fileName);
	 * 
	 * //Create an object of FileInputStream class to read excel file
	 * 
	 * FileInputStream inputStream = new FileInputStream(file);
	 * 
	 * Workbook myWorkbook = null;
	 * 
	 * //Find the file extension by splitting file name in substring and getting
	 * only extension name
	 * 
	 * String fileExtensionName = fileName.substring(fileName.indexOf("."));
	 * 
	 * //Check condition if the file is xlsx file
	 * 
	 * if(fileExtensionName.equals(".xlsx")){
	 * 
	 * //If it is xlsx file then create object of XSSFWorkbook class
	 * 
	 * myWorkbook = new XSSFWorkbook(inputStream);
	 * 
	 * }
	 * 
	 * //Check condition if the file is xls file
	 * 
	 * else if(fileExtensionName.equals(".xls")){
	 * 
	 * //If it is xls file then create object of HSSFWorkbook class
	 * 
	 * myWorkbook = new HSSFWorkbook(inputStream);
	 * 
	 * }
	 * 
	 * //Read sheet inside the workbook by its name
	 * 
	 * Sheet mysheet = myWorkbook.getSheet(sheetName);
	 * System.out.println("sheetName"+sheetName); //Find number of rows in excel
	 * file int rowCount = mysheet.getLastRowNum()-mysheet.getFirstRowNum();
	 * 
	 * 
	 * Map <String, List<String>> dataMap = new LinkedHashMap();
	 * 
	 * 
	 * for(p=1;p<=rowCount;p++) {
	 * 
	 * Row row = mysheet.getRow(p); int
	 * cellcount=row.getLastCellNum()-row.getFirstCellNum();
	 * 
	 * List<String> lt = new ArrayList();
	 * 
	 * for(int q=1;q<cellcount;q++) {
	 * 
	 * if(row.getCell(q).getCellType()==row.getCell(q).getCellType().STRING) {
	 * //System.out.println("value at cell : "+q
	 * +""+row.getCell(q).getStringCellValue());
	 * lt.add(row.getCell(q).getStringCellValue());
	 * 
	 * } else {
	 * 
	 * 
	 * //System.out.println("value at cell : "+q
	 * +""+row.getCell(q).getNumericCellValue());
	 * lt.add(String.valueOf(row.getCell(q).getNumericCellValue()));
	 * 
	 * 
	 * //System.out.println("lt>>>>>>>>>>>>>>>>>>"+lt); }
	 * 
	 * 
	 * 
	 * } dataMap.put(row.getCell(0).getStringCellValue(),lt); }
	 * GenericMethod.closeexcel(myWorkbook); return dataMap;
	 * 
	 * }
	 */

	public static Map<String, List<String>> readExcelInputData2(String filePath, String fileName, String sheetName)
			throws IOException {

		int p = 1;
		// Create an object of File class to open xlsx file

		File file = new File(filePath + "\\" + fileName);

		// Create an object of FileInputStream class to read excel file

		FileInputStream inputStream = new FileInputStream(file);

		Workbook myWorkbook = null;

		// Find the file extension by splitting file name in substring and getting only
		// extension name

		String fileExtensionName = fileName.substring(fileName.indexOf("."));

		// Check condition if the file is xlsx file

		if (fileExtensionName.equals(".xlsx")) {

			// If it is xlsx file then create object of XSSFWorkbook class

			myWorkbook = new XSSFWorkbook(inputStream);

		}

		// Check condition if the file is xls file

		else if (fileExtensionName.equals(".xls")) {

			// If it is xls file then create object of HSSFWorkbook class

			myWorkbook = new HSSFWorkbook(inputStream);

		}

		// Read sheet inside the workbook by its name

		Sheet mysheet = myWorkbook.getSheet(sheetName);
		System.out.println("sheetName" + sheetName);
		// Find number of rows in excel file
		int rowCount = mysheet.getLastRowNum() - mysheet.getFirstRowNum();

		Map<String, List<String>> dataMap2 = new LinkedHashMap();
		Row row1 = mysheet.getRow(0);

		int cellcount = row1.getLastCellNum() - row1.getFirstCellNum();

		System.out.println("value of rowcount in excel input" + rowCount);

		for (p = 1; p <= rowCount; p++) {
			// List<String> lt_key = new ArrayList();
			List<String> lt_data = new ArrayList();
			// lt_key.add(String.valueOf(p));
			/*
			 * for(int q=0;q<cellcount;q++) {
			 * lt_key.add(row1.getCell(q).getStringCellValue());
			 * System.out.println(row1.getCell(q).getStringCellValue()); }
			 */
			Row row = mysheet.getRow(p);

			for (int q = 0; q < cellcount ; q++) {

				// System.out.println("Above error line");

				if (row.getCell(q).getCellType() == row.getCell(q).getCellType().STRING) {
					// System.out.println("below error line>>>>>>>>>>>>>>value at cell : "+ q
					// +""+row.getCell(q).getStringCellValue());
					lt_data.add(row.getCell(q).getStringCellValue());
					// System.out.println(row.getCell(q).getStringCellValue());

				} else {

					// System.out.println("value at cell : "+q
					// +""+row.getCell(q).getNumericCellValue());
					//lt_data.add(String.valueOf(row.getCell(q).getNumericCellValue()));
					DataFormatter formatter = new DataFormatter(Locale.US);
					
					lt_data.add(formatter.formatCellValue(row.getCell(q)));
					
					//lt_data.add(String.valueOf(row.getCell(q).getNumericCellValue()));

					// System.out.println(String.valueOf(row.getCell(q).getNumericCellValue()));
					// System.out.println("lt>>>>>>>>>>>>>>>>>>"+lt);
				}

				// lt_key.add(row.getCell(0).getStringCellValue());

			}
			// System.out.println(lt_key.size()+"sizes"+lt_data.size());
			dataMap2.put("row " + String.valueOf(p), lt_data);
			// lt_data.clear();

			// yield dataMap;
		}
		// return (Iterable<Map<List<String>, List<String>>>) dataMap2;

		// System.out.println("read 2 is called
		// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		System.out.println("datamap size in read 2>>>>>>>>" + dataMap2.size());
		GenericMethod.closeexcel(myWorkbook);
		return dataMap2;

	}

	public static Map<String, List<String>> readExcelMandatoryData(String filePath, String fileName, String sheetName)
			throws IOException {

		int p = 1;
		Predicate<String> checkString = data -> data != null && data.length() > 0;

		// Create an object of File class to open xlsx file//lambda

		File file = new File(filePath + "\\" + fileName);

		// Create an object of FileInputStream class to read excel file

		FileInputStream inputStream = new FileInputStream(file);

		Workbook myWorkbook = null;

		// Find the file extension by splitting file name in substring and getting only
		// extension name

		String fileExtensionName = fileName.substring(fileName.indexOf("."));

		// Check condition if the file is xlsx file

		if (fileExtensionName.equals(".xlsx")) {

			// If it is xlsx file then create object of XSSFWorkbook class

			myWorkbook = new XSSFWorkbook(inputStream);

		}

		// Check condition if the file is xls file

		else if (fileExtensionName.equals(".xls")) {

			// If it is xls file then create object of HSSFWorkbook class

			myWorkbook = new HSSFWorkbook(inputStream);

		}

		// Read sheet inside the workbook by its name

		Sheet mysheet = myWorkbook.getSheet(sheetName);
		System.out.println("sheetName" + sheetName);
		// Find number of rows in excel file
		int rowCount = mysheet.getLastRowNum() - mysheet.getFirstRowNum();

		Map<String, List<String>> dataMap2 = new LinkedHashMap();
		Row row1 = mysheet.getRow(0);

		int cellcount = row1.getLastCellNum() - row1.getFirstCellNum();

		System.out.println("value of rowcount in excel input" + rowCount);

		for (p = 1; p < rowCount; p++) {
			// List<String> lt_key = new ArrayList();
			List<String> lt_data = new ArrayList();
			// lt_key.add(String.valueOf(p));
			/*
			 * for(int q=0;q<cellcount;q++) {
			 * lt_key.add(row1.getCell(q).getStringCellValue());
			 * System.out.println(row1.getCell(q).getStringCellValue()); }
			 */
			Row row = mysheet.getRow(p);

			for (int q = 0; q < cellcount; q++) {

				if (row.getCell(q).getCellType() == row.getCell(q).getCellType().STRING) {

					lt_data.add(checkString.test(row.getCell(q).getStringCellValue())
							? row.getCell(q).getStringCellValue().trim()
							: row.getCell(q).getStringCellValue());

					// lt_data.add(checkString.test(row.getCell(q).getStringCellValue()) ?
					// row.getCell(q).getStringCellValue().replaceAll(row.getCell(q).getStringCellValue(),
					// "") :row.getCell(q).getStringCellValue());

				} else {

					lt_data.add(checkString.test(String.valueOf(row.getCell(q).getNumericCellValue()))
							? String.valueOf(row.getCell(q).getNumericCellValue()).trim()
							: String.valueOf(row.getCell(q).getNumericCellValue()));
					// lt_data.add(checkString.test(String.valueOf(row.getCell(q).getNumericCellValue()))
					// ?
					// String.valueOf(row.getCell(q).getNumericCellValue()).replaceAll(String.valueOf(row.getCell(q).getNumericCellValue()),
					// "") : String.valueOf(row.getCell(q).getNumericCellValue()));
				}

			}
			dataMap2.put("row " + String.valueOf(p), lt_data);

		}

		System.out.println("datamap size in read 2>>>>>>>>" + dataMap2.size());
		GenericMethod.closeexcel(myWorkbook);
		return dataMap2;

	}

	public static Map<String, List<String>> readExcelLengthData(String filePath, String fileName, String sheetName)
			throws IOException {

		int p = 1;
		// Create an object of File class to open xlsx file

		File file = new File(filePath + "\\" + fileName);

		// Create an object of FileInputStream class to read excel file

		FileInputStream inputStream = new FileInputStream(file);

		Workbook myWorkbook = null;

		// Find the file extension by splitting file name in substring and getting only
		// extension name

		String fileExtensionName = fileName.substring(fileName.indexOf("."));

		// Check condition if the file is xlsx file

		if (fileExtensionName.equals(".xlsx")) {

			// If it is xlsx file then create object of XSSFWorkbook class

			myWorkbook = new XSSFWorkbook(inputStream);

		}

		// Check condition if the file is xls file

		else if (fileExtensionName.equals(".xls")) {

			// If it is xls file then create object of HSSFWorkbook class

			myWorkbook = new HSSFWorkbook(inputStream);

		}

		// Read sheet inside the workbook by its name

		Sheet mysheet = myWorkbook.getSheet(sheetName);
		System.out.println("sheetName" + sheetName);
		// Find number of rows in excel file
		int rowCount = mysheet.getLastRowNum() - mysheet.getFirstRowNum();

		Map<String, List<String>> dataMap2 = new LinkedHashMap();
		Row row1 = mysheet.getRow(0);

		int cellcount = row1.getLastCellNum() - row1.getFirstCellNum();

		System.out.println("value of rowcount in excel input" + rowCount);

		for (p = 1; p < rowCount; p++) {
			// List<String> lt_key = new ArrayList();
			List<String> lt_data = new ArrayList();
			// lt_key.add(String.valueOf(p));
			/*
			 * for(int q=0;q<cellcount;q++) {
			 * lt_key.add(row1.getCell(q).getStringCellValue());
			 * System.out.println(row1.getCell(q).getStringCellValue()); }
			 */
			Row row = mysheet.getRow(p);

			for (int q = 0; q < cellcount; q++) {

				if (row.getCell(q).getCellType() == row.getCell(q).getCellType().STRING) {
					// System.out.println("value at cell : "+q
					// +""+row.getCell(q).getStringCellValue());
					lt_data.add(row.getCell(q).getStringCellValue());
					// System.out.println(row.getCell(q).getStringCellValue());

				} else {

					// System.out.println("value at cell : "+q
					// +""+row.getCell(q).getNumericCellValue());
					lt_data.add(String.valueOf(row.getCell(q).getNumericCellValue()));

					// System.out.println(String.valueOf(row.getCell(q).getNumericCellValue()));
					// System.out.println("lt>>>>>>>>>>>>>>>>>>"+lt);
				}

				// lt_key.add(row.getCell(0).getStringCellValue());

			}
			// System.out.println(lt_key.size()+"sizes"+lt_data.size());
			dataMap2.put("row " + String.valueOf(p), lt_data);
			// lt_data.clear();

			// yield dataMap;
		}
		// return (Iterable<Map<List<String>, List<String>>>) dataMap2;

		// System.out.println("read 2 is called
		// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		System.out.println("datamap size in read 2>>>>>>>>" + dataMap2.size());
		GenericMethod.closeexcel(myWorkbook);
		return dataMap2;

	}

	public static Map<String, Map<List<String>, List<String>>> readMandatoryData(String filePath, String fileName,
			String sheetName) throws IOException {

		int p = 1;
		Predicate<String> checkString = data -> data != null && data.length() > 0;
		// lambda to use directly interface, input type string, -> lambda expression
		// we are using lambda expression to directly give the body to method without
		// using method name also called anonymus method
		File file = new File(filePath + "\\" + fileName);
		FileInputStream inputStream = new FileInputStream(file);
		Workbook myWorkbook = null;
		String fileExtensionName = fileName.substring(fileName.indexOf("."));
		if (fileExtensionName.equals(".xlsx")) {
			myWorkbook = new XSSFWorkbook(inputStream);
		} else if (fileExtensionName.equals(".xls")) {
			myWorkbook = new HSSFWorkbook(inputStream);
		}
		Sheet mysheet = myWorkbook.getSheet(sheetName);
		int rowCount = mysheet.getLastRowNum() - mysheet.getFirstRowNum();
		Map<String, Map<List<String>, List<String>>> dataMap2 = new LinkedHashMap();
		Row row1 = mysheet.getRow(0);

		int cellcount = row1.getLastCellNum() - row1.getFirstCellNum();
		List<String> headerList = new ArrayList();

		for (int q = 0; q < cellcount; q++) {

			headerList.add(
					checkString.test(row1.getCell(q).getStringCellValue()) ? row1.getCell(q).getStringCellValue().trim()
							: row1.getCell(q).getStringCellValue());// if else way , ternary operator

		}

		for (p = 1; p <= rowCount; p++) {
			// List<String> lt_key = new ArrayList();
			List<String> lt_data = new ArrayList();
			Map<List<String>, List<String>> dataMap = new LinkedHashMap();
			// lt_key.add(String.valueOf(p));
			/*
			 * for(int q=0;q<cellcount;q++) {
			 * lt_key.add(row1.getCell(q).getStringCellValue());
			 * System.out.println(row1.getCell(q).getStringCellValue()); }
			 */
			Row row = mysheet.getRow(p);

			for (int q = 0; q < cellcount; q++) {

				if (row.getCell(q).getCellType() == row.getCell(q).getCellType().STRING) {
					lt_data.add(checkString.test(row.getCell(q).getStringCellValue())
							? row.getCell(q).getStringCellValue().trim()
							: row.getCell(q).getStringCellValue());

				} else {

					lt_data.add(checkString.test(String.valueOf(row.getCell(q).getNumericCellValue()))
							? String.valueOf(row.getCell(q).getNumericCellValue()).trim()
							: String.valueOf(row.getCell(q).getNumericCellValue()));
				}
			}
			dataMap.put(headerList, lt_data);
			// System.out.println(lt_key.size()+"sizes"+lt_data.size());
			dataMap2.put("row " + String.valueOf(p), dataMap);
			// lt_data.clear();

			// yield dataMap;
		}
		// return (Iterable<Map<List<String>, List<String>>>) dataMap2;

		// System.out.println("read 2 is called
		// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		System.out.println("datamap size in read 2>>>>>>>>" + dataMap2.size());
		// GenericMethod.closeexcel(myWorkbook);
		return dataMap2;

	}
	
	
	
	public static Map<String, List<String>> readExcelDataloss(String filePath, String fileName, String sheetName, String queueName)
			throws IOException {
		int p = 1;
		File file = new File(filePath + "\\" + fileName);
		FileInputStream inputStream = new FileInputStream(file);
		Workbook myWorkbook = null;
		String fileExtensionName = fileName.substring(fileName.indexOf("."));
		if (fileExtensionName.equals(".xlsx")) {
			myWorkbook = new XSSFWorkbook(inputStream);
		} else if (fileExtensionName.equals(".xls")) {
			myWorkbook = new HSSFWorkbook(inputStream);
		}
		Sheet mysheet = myWorkbook.getSheet(sheetName);
		System.out.println("sheetName" + sheetName);
		int cellNumber=GenericMethod.fetchingCellNumberForColumnHeadersInExcel(mysheet,queueName);
		int rowCount = mysheet.getLastRowNum() - mysheet.getFirstRowNum();

		Map<String, List<String>> dataMap = new LinkedHashMap();
		for (p = 1; p <= rowCount; p++) {

			Row row = mysheet.getRow(p);
			if (row.getCell(1).getStringCellValue() != null && !row.getCell(1).getStringCellValue().equals("")) {
				List<String> lt = new ArrayList();

				lt.add(row.getCell(1).getStringCellValue());// 0
				lt.add("id");// 1
				lt.add(row.getCell(3).getStringCellValue());// 2
				lt.add(row.getCell(4).getStringCellValue());// 3
				lt.add(row.getCell(cellNumber).getStringCellValue());// 4
				lt.add(String.valueOf(p));// 5
				dataMap.put(row.getCell(0).getStringCellValue(), lt);
			} else {
				List<String> lt = new ArrayList();
				lt.add(row.getCell(2).getStringCellValue());// 0
				lt.add("xpath");// 1
				lt.add(row.getCell(3).getStringCellValue());// 2
				lt.add(row.getCell(4).getStringCellValue());// 3
				lt.add(row.getCell(cellNumber).getStringCellValue());// 4
				lt.add(String.valueOf(p));// 5
				dataMap.put(row.getCell(0).getStringCellValue(), lt);
			}
		}
		GenericMethod.closeexcel(myWorkbook);
		return dataMap;
	}
	
	
	
	
	
	/*public static  List<String> readExcelWICreated(String filePath, String fileName, String sheetName)
			throws IOException {
		int p = 1;
		File file = new File(filePath + "\\" + fileName);
		FileInputStream inputStream = new FileInputStream(file);
		Workbook myWorkbook = null;
		String fileExtensionName = fileName.substring(fileName.indexOf("."));
		if (fileExtensionName.equals(".xlsx")) {
			myWorkbook = new XSSFWorkbook(inputStream);
		} else if (fileExtensionName.equals(".xls")) {
			myWorkbook = new HSSFWorkbook(inputStream);
		}
		Sheet mysheet = myWorkbook.getSheet(sheetName);
		System.out.println("sheetName" + sheetName);
		int rowCount = mysheet.getLastRowNum() - mysheet.getFirstRowNum();
		
		
		 List<String> list = new ArrayList<>();
		for (p = 1; p <= rowCount; p++) {
		Row row = mysheet.getRow(p);
		
		
		list.add(row.getCell(0).getStringCellValue());//0
		list.add(row.getCell(1).getStringCellValue());//1
		
		
//System.out.println("READ EXCEL LIST>>>>"+list);
		Map<String, List<String>> dataMap = new LinkedHashMap();
		for (p = 1; p <= rowCount; p++) {

			Row row = mysheet.getRow(p);
			if (row.getCell(1).getStringCellValue() != null && !row.getCell(1).getStringCellValue().equals("")) {
				List<String> lt = new ArrayList();

				lt.add(row.getCell(1).getStringCellValue());// 0
				lt.add("id");// 1
				lt.add(String.valueOf(p));// 2
				dataMap.put(row.getCell(0).getStringCellValue(), lt);
			} else {
				List<String> lt = new ArrayList();
				lt.add(row.getCell(2).getStringCellValue());// 0
				lt.add("xpath");// 1
				lt.add(String.valueOf(p));// 2
				dataMap.put(row.getCell(0).getStringCellValue(), lt);
			}
		}
		GenericMethod.closeexcel(myWorkbook);
		
	
		
		}
		return list;
		
	}*/
	
	public static Map<String,String> readExcelWICreated_bk(String filePath, String fileName, String sheetName)
			throws IOException {
		int p = 1;
		File file = new File(filePath + "\\" + fileName);
		FileInputStream inputStream = new FileInputStream(file);
		Workbook myWorkbook = null;
		String fileExtensionName = fileName.substring(fileName.indexOf("."));
		if (fileExtensionName.equals(".xlsx")) {
			myWorkbook = new XSSFWorkbook(inputStream);
		} else if (fileExtensionName.equals(".xls")) {
			myWorkbook = new HSSFWorkbook(inputStream);
		}
		Sheet mysheet = myWorkbook.getSheet(sheetName);
		System.out.println("sheetName" + sheetName);
		int rowCount = mysheet.getLastRowNum() - mysheet.getFirstRowNum();

		Map<String, String> dataMap = new LinkedHashMap();
		for (p = 1; p<=rowCount; p++) {

			Row row = mysheet.getRow(p);
			
				dataMap.put(row.getCell(0).getStringCellValue(), row.getCell(1).getStringCellValue());
			
		}
		GenericMethod.closeexcel(myWorkbook);
		return dataMap;
	}

	public static Map<String,String> Queues_detail(String filePath, String fileName, String sheetName)
			throws IOException {
		int p = 1;
		File file = new File(filePath + "\\" + fileName);
		FileInputStream inputStream = new FileInputStream(file);
		Workbook myWorkbook = null;
		String fileExtensionName = fileName.substring(fileName.indexOf("."));
		if (fileExtensionName.equals(".xlsx")) {
			myWorkbook = new XSSFWorkbook(inputStream);
		} else if (fileExtensionName.equals(".xls")) {
			myWorkbook = new HSSFWorkbook(inputStream);
		}
		Sheet mysheet = myWorkbook.getSheet(sheetName);
		System.out.println("sheetName" + sheetName);
		int rowCount = mysheet.getLastRowNum() - mysheet.getFirstRowNum();

		Map<String, String> dataMap = new LinkedHashMap();
		for (p = 1; p <= rowCount; p++) {

			Row row = mysheet.getRow(p);
			
				dataMap.put(row.getCell(0).getStringCellValue(), row.getCell(1).getStringCellValue());
			
		}
		GenericMethod.closeexcel(myWorkbook);
		return dataMap;
	}
	
	
	/*public static Map<String,String> Routing_Map_bckup(String filePath, String fileName, String sheetName)
			throws IOException {
		int p = 1;
		File file = new File(filePath + "\\" + fileName);
		FileInputStream inputStream = new FileInputStream(file);
		Workbook myWorkbook = null;
		String fileExtensionName = fileName.substring(fileName.indexOf("."));
		if (fileExtensionName.equals(".xlsx")) {
			myWorkbook = new XSSFWorkbook(inputStream);
		} else if (fileExtensionName.equals(".xls")) {
			myWorkbook = new HSSFWorkbook(inputStream);
		}
		Sheet mysheet = myWorkbook.getSheet(sheetName);
		System.out.println("sheetName" + sheetName);
		int rowCount = mysheet.getLastRowNum() - mysheet.getFirstRowNum();

		Map<String, String> dataMap = new LinkedHashMap();
		for (p = 1; p <= rowCount; p++) {

			Row row = mysheet.getRow(p);
			
				dataMap.put(row.getCell(0).getStringCellValue(), row.getCell(1).getStringCellValue());
			
		}
		GenericMethod.closeexcel(myWorkbook);
		return dataMap;
	}
	*/
	
	public static Map<String, List<String>> Routing_Map_bk(String filePath, String fileName, String sheetName, String key)
			throws IOException {
		
		
		
		/*try {

			WIdata = ExcelVisibleRead.readExcelWICreated();
			
		} catch (IOException e) {

		}

		for (Entry<List<String>, List<String>> map : WIdata.entrySet()) {*/
			/*map.getKey();
			map.getValue();
		*/
		
		
		int p = 1;
		File file = new File(filePath + "\\" + fileName);
		FileInputStream inputStream = new FileInputStream(file);
		Workbook myWorkbook = null;
		String fileExtensionName = fileName.substring(fileName.indexOf("."));
		if (fileExtensionName.equals(".xlsx")) {
			myWorkbook = new XSSFWorkbook(inputStream);
		} else if (fileExtensionName.equals(".xls")) {
			myWorkbook = new HSSFWorkbook(inputStream);
		}
		Sheet mysheet = myWorkbook.getSheet(sheetName);
		System.out.println("sheetName" + sheetName);
		int rowCount = mysheet.getLastRowNum() - mysheet.getFirstRowNum();

		Map<String, List<String>> dataMap = new LinkedHashMap();
		for (p = 1; p < rowCount; p++) {

			Row row = mysheet.getRow(p);
			
			List<String> lt = new ArrayList();

			
			//System.out.println("row"+row);
			System.out.println("row.getCell(1)"+row.getCell(1));
			
			lt.add(row.getCell(1).getStringCellValue());
			lt.add(row.getCell(2).getStringCellValue());
			lt.add(row.getCell(3).getStringCellValue());
			
			System.out.println("count p"+ p);
			
			System.out.println("list"+ lt);
		
			
				dataMap.put(key, lt);
				
				System.out.println("dataMap>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+dataMap);

		

		//System.out.println("dataMap>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+dataMap);
		
		GenericMethod.closeexcel(myWorkbook);
		
		
		
	}
		return dataMap;}
		

	public static List<Routing_map> routingMap(String filePath, String fileName, String sheetName)
			throws IOException {

		List<Routing_map> routingMapList = new ArrayList<Routing_map>();

		int p = 1;
		File file = new File(filePath + "\\" + fileName);
		FileInputStream inputStream = new FileInputStream(file);
		Workbook myWorkbook = null;
		String fileExtensionName = fileName.substring(fileName.indexOf("."));
		if (fileExtensionName.equals(".xlsx")) {
			myWorkbook = new XSSFWorkbook(inputStream);
		} else if (fileExtensionName.equals(".xls")) {
			myWorkbook = new HSSFWorkbook(inputStream);
		}
		Sheet mysheet = myWorkbook.getSheet(sheetName);
		System.out.println("sheetName" + sheetName);
		int rowCount = mysheet.getLastRowNum() - mysheet.getFirstRowNum();

		for (p = 1; p < rowCount; p++) {

			Row row = mysheet.getRow(p);

	

			Routing_map rm = new Routing_map();
			rm.setFrom_Queue(row.getCell(0).getStringCellValue());
			rm.setDecision(row.getCell(1).getStringCellValue());
			rm.setTo_Queue(row.getCell(2).getStringCellValue());

			// System.out.println("row"+row);
			System.out.println("row.getCell(0)" + row.getCell(0));
			
			System.out.println("row.getCell(1)" + row.getCell(1));
			System.out.println("row.getCell(2)" + row.getCell(2));

			System.out.println("count p" + p);

			routingMapList.add(rm);

		}

		GenericMethod.closeexcel(myWorkbook);
		return routingMapList;}
	
	
	public static List<Routing_map> SanityroutingMap(String filePath, String fileName, String sheetName)
			throws IOException {

		List<Routing_map> routingMapList = new ArrayList<Routing_map>();

		int p = 1;
		File file = new File(filePath + "\\" + fileName);
		FileInputStream inputStream = new FileInputStream(file);
		Workbook myWorkbook = null;
		String fileExtensionName = fileName.substring(fileName.indexOf("."));
		if (fileExtensionName.equals(".xlsx")) {
			myWorkbook = new XSSFWorkbook(inputStream);
		} else if (fileExtensionName.equals(".xls")) {
			myWorkbook = new HSSFWorkbook(inputStream);
		}
		Sheet mysheet = myWorkbook.getSheet(sheetName);
		System.out.println("sheetName" + sheetName);
		int rowCount = mysheet.getLastRowNum() - mysheet.getFirstRowNum();

		for (p = 1; p < rowCount; p++) {

			Row row = mysheet.getRow(p);

	

			Routing_map rm = new Routing_map();
			rm.setFrom_Queue(row.getCell(0).getStringCellValue());
			rm.setDecision(row.getCell(1).getStringCellValue());
			rm.setTo_Queue(row.getCell(2).getStringCellValue());

			// System.out.println("row"+row);
			System.out.println("row.getCell(0)" + row.getCell(0));
			
			System.out.println("row.getCell(1)" + row.getCell(1));
			System.out.println("row.getCell(2)" + row.getCell(2));

			System.out.println("count p" + p);

			routingMapList.add(rm);

		}

		GenericMethod.closeexcel(myWorkbook);
		return routingMapList;}
	
	
	
	/*public static List<String> getWIList(String filePath, String fileName, String sheetName)
			throws IOException {
		int p = 1;
		File file = new File(filePath + "\\" + fileName);
		FileInputStream inputStream = new FileInputStream(file);
		Workbook myWorkbook = null;
		String fileExtensionName = fileName.substring(fileName.indexOf("."));
		if (fileExtensionName.equals(".xlsx")) {
			myWorkbook = new XSSFWorkbook(inputStream);
		} else if (fileExtensionName.equals(".xls")) {
			myWorkbook = new HSSFWorkbook(inputStream);
		}
		Sheet mysheet = myWorkbook.getSheet(sheetName);
		System.out.println("sheetName" + sheetName);
		int rowCount = mysheet.getLastRowNum() - mysheet.getFirstRowNum();

		List<String> dataMap = new ArrayList<String>();
		for (p = 1; p <=rowCount; p++) {

			Row row = mysheet.getRow(p);
			dataMap.add(row.getCell(0).getStringCellValue());
		}
		GenericMethod.closeexcel(myWorkbook);
		return dataMap;
	}
*/
	
	
	
	public static List<String> getWIList()
			throws IOException {
		
		List<String> list = new ArrayList<String>();
		Base baseObj=new Base();
		String url=baseObj.propertyfromxls("DatabaseURL");
		String username=baseObj.propertyfromxls("DatabaseUsername");
		String password=baseObj.propertyfromxls("DatabasePassword");
		//String sqlQuery=Utils.propertyfromxls("SQLQuery");
		Connection connection=GenericMethod.performingDatabaseConnection(url, username, password);
		
		//ExcelVisibleRead er = new ExcelVisibleRead();
		Map<String, String> queriesmap = ExcelVisibleRead.queries(System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"),
				prop.getProperty("xlsx.file.name"), prop.getProperty("SQLQueries.sheet.name"));
							
		
			
		 Statement statement;
		try {
			statement = connection.createStatement();
			String query = queriesmap.get("SQLQuery");
			
			System.out.println("query222222222++++++++++++++++++++++++++++++++++++++++++++++++++++++++"+query);
			
			
			ResultSet result=statement.executeQuery(query);
			while(result.next()) {
				System.out.println("result.getString(\"WINumber\")+++++++++++++++++++++++++++++++++++++++++++++++++++++++++"+result.getString("WINumber"));
				list.add(result.getString("WINumber"));
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
			
		   try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		return list;
		
		
	}
	
	
	public static Map<String,String> readExcelWICreated()
			throws IOException {
		
		Map<String, String> dataMap = new LinkedHashMap();
		Base baseObj=new Base();
		String url=baseObj.propertyfromxls("DatabaseURL");
		String username=baseObj.propertyfromxls("DatabaseUsername");
		String password=baseObj.propertyfromxls("DatabasePassword");
		//String url=Utils.propertyfromxls("DatabaseURL");
		//String username=Utils.propertyfromxls("DatabaseUsername");
		//String password=Utils.propertyfromxls("DatabasePassword");
		//String sqlQuery=Utils.propertyfromxls("SQLQuery");
		
		//ExcelVisibleRead er = new ExcelVisibleRead();
		Map<String, String> queriesmap = ExcelVisibleRead.queries(System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"),
				prop.getProperty("xlsx.file.name"), prop.getProperty("SQLQueries.sheet.name"));
		                                                             		
			
				
		Connection connection=GenericMethod.performingDatabaseConnection(url, username, password);
		
		 Statement statement;
		try {
			statement = connection.createStatement();
			String query = queriesmap.get("SQLQuery");
			
			System.out.println("query++++++++++++++++++++++++++++++++++++++++++++++++++++++"+query);
			
			ResultSet result=statement.executeQuery(query);
			
			
			
			while(result.next()) {
				System.out.println("result.getString(\"WINumber\")+++++++++++++++++++++++++++++++++++++++++++++++++++++++++"+result.getString("WINumber"));
				
				
				dataMap.put(result.getString("WINumber"),result.getString("currQueue"));
				
			}
			
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
			
			
		   try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   
				
		
			
	
		return dataMap;
	}
	
	public static Map<String, String> queries(String filePath, String fileName, String sheetName)
			throws IOException {
		
		System.out.println("filePath......"+filePath+"fileName........."+fileName+"sheetName.........."+sheetName);
		
		int p = 1;
		File file = new File(filePath + "\\" + fileName);
		FileInputStream inputStream = new FileInputStream(file);
		Workbook myWorkbook = null;
		String fileExtensionName = fileName.substring(fileName.indexOf("."));
		if (fileExtensionName.equals(".xlsx")) {
			myWorkbook = new XSSFWorkbook(inputStream);
		} else if (fileExtensionName.equals(".xls")) {
			myWorkbook = new HSSFWorkbook(inputStream);
		}
		Sheet mysheet = myWorkbook.getSheet(sheetName);
		System.out.println("sheetName" + sheetName);
		int rowCount = mysheet.getLastRowNum() - mysheet.getFirstRowNum();

		Map<String, String> dataMap = new LinkedHashMap();
		for (p = 1; p <= rowCount; p++) {

			Row row = mysheet.getRow(p);
			/*
				List<String> lt1 = new ArrayList();

				lt1.add(row.getCell(0).getStringCellValue());// 0
				
				List<String> lt2 = new ArrayList();
				lt2.add(row.getCell(1).getStringCellValue());// 0
*/				
				System.out.println("queries");
			
				dataMap.put(row.getCell(0).getStringCellValue(), row.getCell(1).getStringCellValue());
		}
		GenericMethod.closeexcel(myWorkbook);
		return dataMap;
	}
	
	
}