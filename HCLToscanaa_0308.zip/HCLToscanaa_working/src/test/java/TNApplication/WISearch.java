package TNApplication;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.constant.ToscanaConstant;
import com.util.Utils;

import Resource.Base;
import junit.framework.Assert;
import net.bytebuddy.asm.Advice.Exit;

public class WISearch extends Base{
	
	static String final_WIList_SearchedOnWrongQueue="";
    static String final_WIList_NotSearched="";
	
	//@Test(priority = 1)
	public void DashboardPagelogin() {

		System.out.println("IN DashboardPagelogin");
		driver.get(super.propertyfromxls("dashboardurl"));

		logger.info("ToscanaLogin : inside DashboardPagelogin() method");

		driver.findElement(By.xpath(super.propertyfromxls("DashboardUsernameXPATH")))
				.sendKeys(super.propertyfromxls("dashusername"));
		driver.findElement(By.xpath(super.propertyfromxls("DashboardPasswordXPATH")))
				.sendKeys(super.propertyfromxls("dashpswrd"));
		driver.findElement(By.xpath(super.propertyfromxls("DashboardLoginBUTTON"))).click();

		logger.info("ToscanaLogin : Login successful");
		logger.info("ToscanaLogin : Application login smoke ran successfully");

		try {
			/*
			 * Assert.assertEquals(LengthAccepting>0, true); flag= true;
			 */
			ReportGenerator.onTestSuccess("DashboardPagelogin");
		} catch (Throwable throwable) {
			// flag= false;
			ReportGenerator.onTestFailure(throwable, "DashboardPagelogin");
		}

	}
	
	
	
	@BeforeClass
	public void clean_test_result() {
		//logger.info("FormSubmission: Inside clean_test_result()");
		 try {
			   TestCasesResultWrite.clean_test_result_visibility(ToscanaConstant.SubModule_WI_search);
			
			   }catch(Exception E) {
				   //logger.error("FormSubmission: Inside clean_test_result(): error {}", E);
				   E.printStackTrace();
			   }
 }
	
	
	@Test(dataProvider = "Database-data-provider", dataProviderClass = DP.class, priority = 1)
	public void inputdataInSearchBoxAndValidation1(String key,String value) throws Exception{
		
		String filename=System.getProperty("user.dir")+prop.getProperty("xlsx.file.path");
		//String filename="C:\\Users\\vibhor-g\\eclipse-workspace\\HCLToscanaa.zip_expanded\\HCLToscanaa\\Exceldata\\ToscanaInput.xlsx";
	    String sheetname=prop.getProperty("DatabaseExtract.sheet.name");
		//String sheetname="DatabaseExtract_Output";
	    FileInputStream fis=new FileInputStream(filename);
		XSSFWorkbook wbookObj= new XSSFWorkbook(fis);
	    XSSFSheet sheetObj=wbookObj.getSheet(sheetname);
	    int rownum=sheetObj.getLastRowNum();
	    int row=rownum+1;
	    sheetObj.createRow(row);
	    String columnHeadersCelltxt=super.propertyfromxls("DatabaseOutputExtract_ColumnHeadersInExcel");
	    List<String> columnHeaderNamesList=GenericMethod.valueExtractionFromCombinedCelltxt(columnHeadersCelltxt);
	    Map <String,Integer> dataMap = new HashMap<String,Integer>();
	    for (String columnHeaderName : columnHeaderNamesList) {
	    	System.out.println(columnHeaderName);
	    	int cellNumber=GenericMethod.fetchingCellNumberForColumnHeadersInExcel(sheetObj, columnHeaderName);
	    	System.out.println(cellNumber);
	    	dataMap.put(columnHeaderName, cellNumber);
		}
	    FileOutputStream fileOut=null;
	    Map<String, String> Queues_detail_Data = ExcelVisibleRead.Queues_detail(System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"),
	    		prop.getProperty("xlsx.file.name"), prop.getProperty("Queues_detail_WISearch.sheet.name"));
	    
	    String parameterName=super.propertyfromxls("ParameterNameOnFrontEnd");
	    List<String> statusObj=new ArrayList<String>();
	    boolean result=true;
	    
		String wiNumberExtractedFromDatabase=key;
		String queueNameExtractedFromDatabase=value;
			//Thread.sleep(2000);
		    for (String queuename : Queues_detail_Data.keySet()) {
				System.out.println(queuename);
				driver.findElement(By.xpath(Queues_detail_Data.get(queuename).trim())).click();
				System.out.println(Queues_detail_Data.get(queuename).trim());
				//Thread.sleep(2000);
				driver.findElement(By.xpath(super.propertyfromxls("Searchbox"))).clear();
				System.out.println(super.propertyfromxls("Searchbox"));
				Thread.sleep(2000);
				driver.findElement(By.xpath(super.propertyfromxls("Searchbox"))).sendKeys(wiNumberExtractedFromDatabase);
				//Thread.sleep(2000);
				int indexNumber=fetchingIndexNumberForParameterFromFrontEnd(parameterName);
				String fetchedValue=fetchingValuesForParameterFromFrontEnd(indexNumber);
				Thread.sleep(2000);
				
				if(wiNumberExtractedFromDatabase.trim().equals(fetchedValue.trim())){
					
					if(queuename.equalsIgnoreCase(queueNameExtractedFromDatabase)) {
						System.out.println("Searched Result Pass,"+wiNumberExtractedFromDatabase.trim()+" present "+"in queue "+queuename);
						sheetObj.getRow(row).createCell(dataMap.get("Search_Status_"+queuename)).setCellValue("Present/Pass");
						String status=sheetObj.getRow(row).getCell(dataMap.get("Search_Status_"+queuename)).getStringCellValue();
						statusObj.add(status);
					}else {
						System.out.println("Searched Result Fail,"+wiNumberExtractedFromDatabase.trim()+" present "+"in queue "+queuename);
						sheetObj.getRow(row).createCell(dataMap.get("Search_Status_"+queuename)).setCellValue("Present/Fail");
						String status=sheetObj.getRow(row).getCell(dataMap.get("Search_Status_"+queuename)).getStringCellValue();
						statusObj.add(status);
						final_WIList_SearchedOnWrongQueue=final_WIList_SearchedOnWrongQueue+wiNumberExtractedFromDatabase.trim()+" ";
						}
					}else {
						if(!queuename.equalsIgnoreCase(queueNameExtractedFromDatabase)) {
							System.out.println("Searched Result Pass,"+wiNumberExtractedFromDatabase.trim()+" not present "+"in queue "+queuename);
							sheetObj.getRow(row).createCell(dataMap.get("Search_Status_"+queuename)).setCellValue("Not Present/Pass");
							String status=sheetObj.getRow(row).getCell(dataMap.get("Search_Status_"+queuename)).getStringCellValue();
							statusObj.add(status);
						}else {
							System.out.println("Searched Result Fail,"+wiNumberExtractedFromDatabase.trim()+" not present "+"in queue "+queuename);
							sheetObj.getRow(row).createCell(dataMap.get("Search_Status_"+queuename)).setCellValue("Not Present/Fail");
							String status=sheetObj.getRow(row).getCell(dataMap.get("Search_Status_"+queuename)).getStringCellValue();
							statusObj.add(status);
							final_WIList_NotSearched=final_WIList_NotSearched+wiNumberExtractedFromDatabase.trim()+" ";
						     }
						}
				}	
				/*if(wiNumberInExcel.trim().equals(fetchedValue.trim()) && queuename.equalsIgnoreCase(queueNameInExcel)) {
					System.out.println("Searched Result Pass,"+wiNumberInExcel.trim()+" present"+"in queue "+queuename);
					sheetObj.getRow(i).createCell(dataMap.get("Search_Status")).setCellValue("Present");
					String status=sheetObj.getRow(i).getCell(dataMap.get("Search_Status")).getStringCellValue();
					statusObj.add(status);
				}else {
					
					System.out.println("Searched Result Fail,"+wiNumberInExcel.trim()+" not present");
					sheetObj.getRow(i).createCell(dataMap.get("Search_Status")).setCellValue("Not Present");
					String status=sheetObj.getRow(i).getCell(dataMap.get("Search_Status")).getStringCellValue();
					statusObj.add(status);
					final_WIList_NotSearched=final_WIList_NotSearched+wiNumberInExcel.trim()+" ";
				}*/
			
			/*String queueNamesCelltxt=super.propertyfromxls("SubStatus_based_QueueNames");
		    List<String> queueNamesList=GenericMethod.valueExtractionFromCombinedCelltxt(queueNamesCelltxt);
		    for (String queueName : queueNamesList) {
				if(queueNameInExcel.equalsIgnoreCase(queueName.trim())) {
					driver.findElement(By.xpath(super.propertyfromxls(queueName))).click();
					break;
				}
			}*/
		    
		    
			/*if(queueNameInExcel.equalsIgnoreCase("Differently abled / Old age")) {
				driver.findElement(By.xpath("//*[text()='Closed Cases']")).click();
			}else if (queueNameInExcel.equalsIgnoreCase("Travel Pass related")) {
				driver.findElement(By.xpath("//*[text()='Closed Cases']")).click();
			}else if (queueNameInExcel.equalsIgnoreCase("Medical / Health")) {
				driver.findElement(By.xpath("//*[text()='Closed Cases']")).click();
			}else {
				driver.findElement(By.xpath("//*[text()='"+queueNameInExcel+"']")).click();
			}*/
		    
      
		for (String columnHeaderName : columnHeaderNamesList) {
	    	sheetObj.autoSizeColumn(dataMap.get(columnHeaderName));
		}
		
		if(final_WIList_SearchedOnWrongQueue=="") {
		 result=true;	
		 TestCasesResultWrite.writeData3(String.valueOf(result),ToscanaConstant.SubModule_WI_search,"QueueName");
		}else {
		 result=false;
		 TestCasesResultWrite.writeData3(String.valueOf(result),ToscanaConstant.SubModule_WI_search,"QueueName");
		 TestCasesResultWrite.writeData5(final_WIList_SearchedOnWrongQueue,ToscanaConstant.SubModule_WI_search,"QueueName");
		}
		
		try {
			assertEquals(result, true);
				ReportGenerator.onTestSuccess("SearchWIValidation_"+"QueueName");
				}catch(Throwable throwable) {
					ReportGenerator.onTestFailure(throwable, "SearchWIValidation_"+"QueueName");
				}	
			
		if(final_WIList_NotSearched=="") {
			 result=true;	
			 TestCasesResultWrite.writeData3(String.valueOf(result),ToscanaConstant.SubModule_WI_search,"WINumber");
			}else {
			 result=false;
			 TestCasesResultWrite.writeData3(String.valueOf(result),ToscanaConstant.SubModule_WI_search,"WINumber");
			 TestCasesResultWrite.writeData5(final_WIList_NotSearched,ToscanaConstant.SubModule_WI_search,"WINumber");
			}
			
		try {
			assertEquals(result, true);
				ReportGenerator.onTestSuccess("SearchWIValidation_"+"WINumber");
				}catch(Throwable throwable) {
					ReportGenerator.onTestFailure(throwable, "SearchWIValidation_"+"WINumber");
				}	
				
			
		/*if(statusObj.contains("Not Present")) {
				result=false;
				
				//TestCasesResultWrite.writeData4(String.valueOf(result),ToscanaConstant.SubModule_WI_search);
				TestCasesResultWrite.writeData3(String.valueOf(result),ToscanaConstant.SubModule_WI_search,columnHeaderNamesList.get(1));
			}else {
				//TestCasesResultWrite.writeData4(String.valueOf(result),ToscanaConstant.SubModule_WI_search);
				result=true;
				TestCasesResultWrite.writeData3(String.valueOf(result),ToscanaConstant.SubModule_WI_search,columnHeaderNamesList.get(1));
			}*/
		
		fileOut=new FileOutputStream(filename);
		wbookObj.write(fileOut);
		wbookObj.close();
		
	}
	
	
	
	@Test(priority = 2)
	public void dashboardPagelogout() {
        
		logger.info("ToscanaLogin : inside dashboardPagelogout() method");
        driver.findElement(By.xpath(super.propertyfromxls("DashboardClicklogout"))).click();
	    driver.findElement(By.xpath(super.propertyfromxls("Dashboardlogoutbutton"))).click();
        logger.info("ToscanaLogin :Logout successful");
		
		try {
				/*Assert.assertEquals(LengthAccepting>0, true);
				flag= true;*/
				ReportGenerator.onTestSuccess("dashboardPagelogout");
				}catch(Throwable throwable) {
					//flag= false;
					ReportGenerator.onTestFailure(throwable, "dashboardPagelogout");
				}
		
	}
	
	
	
	public int fetchingIndexNumberForParameterFromFrontEnd(String parameterName){
		int i=0;
		WebElement tableObj=driver.findElement(By.xpath(super.propertyfromxls("WebTable")));
		List<WebElement> columnHeadersList=tableObj.findElements(By.xpath(super.propertyfromxls("ColumnHeadersXPath")));
		System.out.println(columnHeadersList.size());
		for (i=0;i<columnHeadersList.size();i++) {
			
			if(columnHeadersList.get(i).getText().trim().equalsIgnoreCase(parameterName)) {
				break;
			}
		}
		return i;
	}
	
	public String fetchingValuesForParameterFromFrontEnd(int indexNo){
		
		String fetchedValue=null;
		WebElement tableObj=driver.findElement(By.xpath(super.propertyfromxls("WebTable")));
		try {
			WebElement searchedRecord=tableObj.findElement(By.xpath(super.propertyfromxls("SearchedRecordXPath")));
			WebElement fetchedObj=searchedRecord.findElement(By.xpath("//td["+(indexNo+1)+"]/a"));
			fetchedValue=fetchedObj.getText();
		}catch(NoSuchElementException e) {
			
			fetchedValue="Record Not Found";
		}
		
		return fetchedValue;
		
	}
	
	
}