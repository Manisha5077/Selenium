package TNApplication;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import Resource.Base;

public class ToscanaLogin extends Base {

	public static Logger logger = LogManager.getLogger(ToscanaLogin.class);
	//public static Logger logger = LogManager.getLogger("GLOBAL");
	public static String suiteFileName=System.getProperty("user.dir")+prop.getProperty("xlsx.suitefile.path");
	public static HSSFWorkbook workbook;
	public static HSSFSheet worksheet;
	public static String ColName = "Status";
	public static int col_num;
	public static String inputFileName=System.getProperty("user.dir")+prop.getProperty("xlsx.file.path");
	
	@Test(groups = { "smokeTest" }, priority = 1)
	public void FrontlinePagelogout() {
		
		System.out.println("******************************************************INSIDE LOGIN*****************************************************");
        
		logger.info("ToscanaLogin : inside FrontlinePagelogout() method");
    System.out.println(System.getProperty("user.dir"));
		driver.get(super.propertyfromxls("url"));
    
		
		logger.info("ToscanaLogin :  Application Url opened successfully");

		driver.findElement(By.xpath(super.propertyfromxls("Clicklogout"))).click();
	
		driver.findElement(By.xpath(super.propertyfromxls("logoutbutton"))).click();

		logger.info("ToscanaLogin :Logout successful");
		
		try {
				
				ReportGenerator.onTestSuccess("FrontlinePagelogout");
				}catch(Throwable throwable) {
			
					ReportGenerator.onTestFailure(throwable, "FrontlinePagelogout");
				}
		
	}

	@Test(groups = { "smokeTest" }, priority = 2)
	public void FrontlinePagelogin() {

		logger.info("ToscanaLogin : inside FrontlinePagelogin() method");

		driver.findElement(By.xpath(super.propertyfromxls("FrontlineuserNamexpath")))
				.sendKeys(super.propertyfromxls("username"));
		driver.findElement(By.xpath(super.propertyfromxls("Frontlinepasswordxpath")))
				.sendKeys(super.propertyfromxls("password"));
		driver.findElement(By.xpath(super.propertyfromxls("loginbutton"))).click();

		logger.info("ToscanaLogin : Login successful");
		logger.info("ToscanaLogin : Application login smoke ran successfully");
		
		try {

			ReportGenerator.onTestSuccess("FrontlinePagelogin");
			}catch(Throwable throwable) {

				ReportGenerator.onTestFailure(throwable, "FrontlinePagelogin");
			}
		
	}

	
	@Test(priority = 3)
	public void MakeExcelSuiteResultClear() throws IOException {

		FileInputStream fis = new FileInputStream(suiteFileName);
		FileOutputStream fos = null;
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("TestSuite");
		System.out.println(sheet.getLastRowNum());
		XSSFRow row = null;
		//XSSFCell cell = null;
		
		for (int i = 1; i <= sheet.getLastRowNum(); i++) {

			row = sheet.getRow(i);
		
				XSSFCell result_cell = row.getCell(9);
	            result_cell.setCellValue("");
	         
	       }

	
	    
		//fos = new FileOutputStream("C:\\Users\\vibhor-g\\eclipse-workspace\\HCLToscanaa\\Exceldata\\TestSuite.xlsx");
		fos = new FileOutputStream(suiteFileName);
		workbook.write(fos);
		fos.close();
		workbook.close();
		
}

		

}