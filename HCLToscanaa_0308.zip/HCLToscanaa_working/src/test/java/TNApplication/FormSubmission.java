package TNApplication;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
//import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
//import org.apache.poi.hssf.usermodel.HSSFWorkbook;
//import org.apache.poi.sl.usermodel.Sheet;
//import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITest;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
//import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.constant.ToscanaConstant;
import com.util.Utils;

import Resource.Base;
import junit.framework.Assert;


public class FormSubmission extends Base implements ITest{
	
	public static Logger logger = LogManager.getLogger(FormSubmission.class);

	WebDriverWait wait = new WebDriverWait(driver,40);
	private ThreadLocal<String> testName = new ThreadLocal<>();
	
	SoftAssert softAssertion = new SoftAssert();

	 Map<String,List<String>> map=new HashMap<String,List<String>>();
	 Map<String, List<String>> data=null;
	 static String AlertTextContains=Utils.propertyfromxls("AlertText");

	static int i = 0;
	
	@BeforeClass
	public void clean_test_result() {
		//logger.info("FormSubmission: Inside clean_test_result()");
		 try {
			  // TestCasesResultWrite.clean_test_result_visibility(ToscanaConstant.SubModule_enable_check);
			  TestCasesResultWrite.clean_test_result_visibility(ToscanaConstant.SubModule_input_check);
			   
			   }catch(Exception E) {
				   //logger.error("FormSubmission: Inside clean_test_result(): error {}", E);
				   E.printStackTrace();
			   }
	}
	
	
	@Test(dataProvider = "enable-data-provider", dataProviderClass = DP.class, priority = 1,groups="enable")
	public void EnableCheck(String key,List<String> list) throws FileNotFoundException
	
	{ 
		
		//logger.info("FormSubmission: Inside EnableCheck()");
		
		//System.out.println("******************************************************INSIDE ENABLE CHECK*****************************************************");
		
		map.put(key, list);
		
	}

	@Test(dataProvider = "input-data-provider", dataProviderClass = DP.class, priority = 2)
	
	public void InputCheck(String key,List<String> list) {

		System.out.println("******************************************************INSIDE INPUT CHECK*****************************************************");
	
		if(list.size()==0) {
			return;
		}
		try {
		 data = ExcelVisibleRead.readExcel(System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"), prop.getProperty("xlsx.file.name"),
				prop.getProperty("enable.sheet.name"));
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		//boolean result = false;
	{
		for(int i=0;i<list.size();i++) {

		try {
			List<String> mapList= map.get(data.keySet().toArray()[i]);//map.get(key), for sequence fix

			WebElement element=GenericMethod.Find_element(mapList.get(2),mapList.get(0));
			
			
			if(mapList.get(1).equalsIgnoreCase("input")) {
				
				GenericMethod.sendkeys(mapList.get(2), mapList.get(0), list.get(i));

			}
			
			else {

				GenericMethod.sendkeys_To_dropdown(mapList.get(2), mapList.get(0), list.get(i));
				
			}

			
		}

		catch (Exception e) {
			
	
		}
		
		
		}
		
		
		}
	
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	driver.findElement(By.xpath(super.propertyfromxls("Savebutton"))).click();
	wait.until(ExpectedConditions.alertIsPresent());
	boolean result=isAlertPresent();

	
	driver.navigate().refresh();
	
	try {
		
		TestCasesResultWrite.writeData3(String.valueOf(result), ToscanaConstant.SubModule_input_check, key);

		
		}catch(Exception E) {
			E.printStackTrace();
		}
	
	try {
		assertEquals(result, true);
		result= true;
			ReportGenerator.onTestSuccess("InputCheck_"+key);
			}catch(Throwable throwable) {
				result= false;
				ReportGenerator.onTestFailure(throwable, "InputCheck_"+key);
			}
	
	}
	public static boolean isAlertPresent() 
	{ 
		
		Alert Alert =   driver.switchTo().alert();	

		String AlertText = Alert.getText();

		String AlertSubtext = AlertText.substring(40, AlertText.length());
		
	    try 
	    { 

         	 if(AlertText.contains(AlertTextContains))
	    	{
         		Alert.accept(); 
	        driver.navigate().refresh();
	      
	        return true; 
	        
	    	}
         	 
         	 else 
         	 {
         		 driver.navigate().refresh();
         		 System.out.println("AlertText FOUND"+AlertText);
         		 return false; 
         	 }
	    	
	    }  
	    catch (Exception E) 
	    { 
	    	
	    	driver.navigate().refresh();
	        return false; 
	    }  
	    
	    
	   
	    
	}
	

	
	@Override
	public String getTestName() {
	
	   return testName.get();
	}

	
}
