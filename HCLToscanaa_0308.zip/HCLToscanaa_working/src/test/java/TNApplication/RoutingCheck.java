package TNApplication;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.awt.Window;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import Resource.Base;

public class RoutingCheck extends Base {

	WebDriverWait wait = new WebDriverWait(driver, 40);

	static Map<String, String> WIdata = null;
	static Map<String, List<String>> data = null;
	static Map<String, List<String>> data2 = null;
	static List<Routing_map> Routing_Map_Data = null;
	static Map<String, String> Queues_detail_Data = null;
	Map<String, String> map = new HashMap<String, String>();


	

	@Test(dataProvider = "WICreated-data-provider", dataProviderClass = DP.class, priority = 1)
	public void Dataflow_RouteNextLevel(String key, String Value) {
		
		System.out.println("******************************************************INSIDE ROUTE CHECK*****************************************************");

		map.put(key, Value);

		try {

			Routing_Map_Data = ExcelVisibleRead.routingMap(
					System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"),
					prop.getProperty("xlsx.file.name"), prop.getProperty("Routing_Map.sheet.name"));

		} catch (Exception e) {

			e.printStackTrace();

		}

		try {

			Queues_detail_Data = ExcelVisibleRead.Queues_detail(
					System.getProperty("user.dir") + prop.getProperty("xlsx.file.folder.path"),
					prop.getProperty("xlsx.file.name"), prop.getProperty("Queues_detail_WISearch.sheet.name"));

		} catch (Exception e) {

			e.printStackTrace();
		}

	
			
			for(int i =0;i<Routing_Map_Data.size();i++) {
				
				Routing_map routing_map = Routing_Map_Data.get(i);
				
				
				System.out.println("routing_map+++++++++++++++++++++++++++++++++++++++++"+routing_map);
				
				System.out.println("Value+++++++++++++++++++++++++++++++++++++++++"+Value);
				
				if(Value.equalsIgnoreCase(routing_map.getFrom_Queue())) {       
					
					System.out.println("INSIDE IF _________________________________________________________________");
					
					driver.navigate().refresh();
					
					try{

					 Thread.sleep(5000);
					 
					}
					
					catch(Exception e) {
						
						
					}
					
					
					

					driver.findElement(By.xpath(Queues_detail_Data.get(routing_map.From_Queue)))
							.click();

					driver.findElement(By.xpath(super.propertyfromxls("SearchBox"))).click();

					driver.findElement(By.xpath(super.propertyfromxls("SearchBox"))).sendKeys(key);

					driver.findElement(By.xpath(
							"/html/body/div[1]/div/div/div/div[3]/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div/div[1]/table/tbody[1]/tr[2]/td[1]/a"))
							.click();

					String mainWindow = driver.getWindowHandle();
					Set<String> s = driver.getWindowHandles();
					Iterator<String> itr = s.iterator();
					while (itr.hasNext()) {
						String childWindow = itr.next();

						if (!mainWindow.equals(childWindow)) {
							driver.switchTo().window(childWindow);

						}
					}

					try{

						 Thread.sleep(5000);
						 
						}
						
						catch(Exception e) {
							
							
						}

					Select dropdown = new Select(
							driver.findElement(By.xpath(super.propertyfromxls("QueueSelectionFieldXPATH"))));


					dropdown.selectByIndex(2);//this

					driver.findElement(By.xpath(super.propertyfromxls("Submit_ON_Next_QueueSelection"))).click();
				
					driver.switchTo().window(mainWindow);

					driver.navigate().refresh();
					
					driver.findElement(By.xpath(Queues_detail_Data.get(routing_map.getTo_Queue())))
					.click();
					
					  for (Map.Entry<String, String> Queues_detail_Data_map :
					  Queues_detail_Data.entrySet()) {
					  
					  if(routing_map.getTo_Queue().equalsIgnoreCase(
					  Queues_detail_Data_map.getKey())) {
					  
					  
					  driver.findElement(By.xpath(Queues_detail_Data_map.getValue())).click();
					  
					  } 
					  }
					  try{

							 Thread.sleep(5000);
							 
							}
							
							catch(Exception e) {
								
								
							}
					  driver.findElement(By.xpath(super.propertyfromxls("SearchBox"))).click();
					  
					 driver.findElement(By.xpath(super.propertyfromxls("SearchBox"))).sendKeys(key);

					 try{

						 Thread.sleep(5000);
						 
						}
						
						catch(Exception e) {
							
							
						}
		
					 DataLoss DLC = new DataLoss();
					 //DLC.dataloss3();

					 
					 Routing_Map_Data.remove(routing_map);
					 
					 i=-1;
					 
					 Value=routing_map.getTo_Queue(); //making "from Q" = "to Q"
				}
					
				
				}
	}
	
}

