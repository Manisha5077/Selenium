package TNApplication;

import static org.testng.Assert.fail;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
//import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import org.apache.commons.io.FileUtils;
/*import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;*/
//import org.apache.logging.log4j.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
/*import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
import org.junit.jupiter.api.function.Executable;*/
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.ITest;
import org.testng.ITestContext;
import org.testng.ITestResult;
//import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Factory;
//import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.constant.ToscanaConstant;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
import org.junit.jupiter.api.function.Executable;
//import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.testng.ITest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Resource.Base;

 public class FieldVisibility  extends Base  implements ITest{

	public static Logger logger = LogManager.getLogger(FieldVisibility.class);

	Map<String, List<String>> data = null;
	SoftAssert softAssertion = new SoftAssert();
	String locator;
	String path;
	private ThreadLocal<String> testName = new ThreadLocal<>();

	@BeforeClass
	public void clean_test_result() {
		//logger.info("VisibilityCheck: Inside clean_test_result()");
		 try {
			   TestCasesResultWrite.clean_test_result_visibility(ToscanaConstant.SubModule_Visilbility_check);
			   
			   }catch(Exception E) {
				   E.printStackTrace();
			   }
	}
	@Test (dataProvider = "visible-data-provider", dataProviderClass = DP.class)
	
	public void VisibleTestCase(String key,List<String> list) {
		//logger.info("VisibilityCheck: Inside VisibleTestCase()");
		
		System.out.println("******************************************************INSIDE VISIBILITY CHECK*****************************************************");

		boolean result = false;

	try {

		WebElement element=GenericMethod.Find_element(list.get(1), list.get(0));//1=locType, 0=xpathorid_value
		
		if(element!=null&key.equals(element.getText())) {
		result=element.isDisplayed();
		}		
	}
	catch(Exception e) {
		
	}
		try {
			
			TestCasesResultWrite.writeData3(String.valueOf(result),ToscanaConstant.SubModule_Visilbility_check,key);
		} catch (Exception e) {
			//logger.error("VisibilityCheck: Inside VisibleTestCase(): Inside writeData3: error {}", e);
			
			e.printStackTrace();  
		}

		try {
			assertEquals(result, true);
			result= true;
				ReportGenerator.onTestSuccess("VisibleTestCase_"+key);
				}catch(Throwable throwable) {
					result= false;
					ReportGenerator.onTestFailure(throwable, "VisibleTestCase_"+key);
				}	
	}



//method in ITest interface
	@Override
	public String getTestName() {
		//logger.info("VisibilityCheck: Inside getTestName()");
	   return testName.get();
	}
}


