package TNApplication;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Resource.Base;
 
public class OutputInExcel extends Base{
 
	/*public static void main (String [] args) throws IOException{
		//create an object of Workbook and pass the FileInputStream object into it to create a pipeline between the sheet and eclipse.
		FileInputStream fis = new FileInputStream("C:\\Auto_work\\Test.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		//call the getSheet() method of Workbook and pass the Sheet Name here. 
		//In this case I have given the sheet name as �TestData� 
                //or if you use the method getSheetAt(), you can pass sheet number starting from 0. Index starts with 0.
		XSSFSheet sheet = workbook.getSheet("TestData");
		//XSSFSheet sheet = workbook.getSheetAt(0);
		//Now create a row number and a cell where we want to enter a value. 
		//Here im about to write my test data in the cell B2. It reads Column B as 1 and Row 2 as 1. Column and Row values start from 0.
		//The below line of code will search for row number 2 and column number 2 (i.e., B) and will create a space. 
                //The createCell() method is present inside Row class.
                Row row = sheet.createRow(1);
		Cell cell = row.createCell(1);
		//Now we need to find out the type of the value we want to enter. 
                //If it is a string, we need to set the cell type as string 
                //if it is numeric, we need to set the cell type as number
		//cell.setCellType(cell.CELL_TYPE_STRING);
		cell.setCellValue("SoftwareTestingMaterial.com");
		
		
		
		
		
		FileOutputStream fos = new FileOutputStream("C:\\Auto_work\\Test.xlsx");
		workbook.write(fos);
		fos.close();
		System.out.println("END OF WRITING DATA IN EXCEL");
	}*/
	
	public static void wi_WriteInExcel(String IssueType,String SubIssueType,String WI) {
		
		    XSSFWorkbook workbook=null;
		    XSSFSheet sheet=null;
	  try {
			String filename="C:\\Users\\vibhor-g\\Desktop\\HCLToscanaa\\HCLToscanaa\\Exceldata\\Generated_WI.xlsx";
			File file=new File(filename);
			if(file.exists()==true) {
				FileInputStream fis=new FileInputStream(file);
				workbook=new XSSFWorkbook(fis);
			}else {
				workbook=new XSSFWorkbook();
			}
			
			if(workbook.getNumberOfSheets()==0) {
			sheet=workbook.createSheet("WI");
			}else {
				sheet=workbook.getSheet("WI");
			}
			int rownum=sheet.getLastRowNum();
			if(rownum==-1) {
				XSSFRow rowhead=sheet.createRow((short)0);
				rowhead.createCell(0).setCellValue("IssueType");
				rowhead.createCell(1).setCellValue("SubIssueType");
				rowhead.createCell(2).setCellValue("WI_generated");
				
			}
				rownum=sheet.getLastRowNum()+1;
				XSSFRow row=sheet.createRow((short)rownum);
				row.createCell(0).setCellValue(IssueType);
				row.createCell(1).setCellValue(SubIssueType);
				row.createCell(2).setCellValue(WI);

			
			FileOutputStream fileOut=new FileOutputStream(filename);
			workbook.write(fileOut);
			fileOut.close();
			workbook.close();
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		//return workbook;
	}
	
	public static void wi_WriteInExcelSearchResult(List<String> columnHeaderNamesList) {
		
	    XSSFWorkbook workbook=null;
	    XSSFSheet sheet=null;
  try {
		String filename=System.getProperty("user.dir")+prop.getProperty("xlsx.file.path");
	    //String filename="C:\\Users\\vibhor-g\\eclipse-workspace\\HCLToscanaa.zip_expanded\\HCLToscanaa\\Exceldata\\ToscanaInput.xlsx";
		String sheetname=prop.getProperty("DatabaseExtract.sheet.name");
	    //String sheetname="DatabaseExtract_Output";
		//String sheetname="Filtered_Result";
		FileInputStream fis=new FileInputStream(filename);
			workbook=new XSSFWorkbook(fis);
			if(workbook.getSheet(sheetname)==null) {
				sheet=workbook.createSheet(sheetname);
			}else {
				sheet=workbook.getSheet(sheetname);
			}
		
			XSSFRow rowhead=sheet.createRow((short)0);
			for(int i=0;i<columnHeaderNamesList.size();i++) {
				
			 rowhead.createCell(i).setCellValue(columnHeaderNamesList.get(i));
			}
	
		
		FileOutputStream fileOut=new FileOutputStream(filename);
		workbook.write(fileOut);
		fileOut.close();
		workbook.close();
		
		
	} catch (Exception e) {
		// TODO: handle exception
	}
	//return workbook;
}

	
}