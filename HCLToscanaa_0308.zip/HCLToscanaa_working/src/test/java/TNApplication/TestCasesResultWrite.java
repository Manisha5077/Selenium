package TNApplication;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Resource.Base;

public class TestCasesResultWrite extends Base{

	public static HSSFWorkbook workbook;
	public static HSSFSheet worksheet;
	public static String ColName = "Status";
	public static int col_num;
	public static String inputFileName=System.getProperty("user.dir")+prop.getProperty("xlsx.file.path");
	public static String suiteFileName=System.getProperty("user.dir")+prop.getProperty("xlsx.suitefile.path");

	public static void writeData(int rowNo, String data) throws Exception {
		FileInputStream fis = new FileInputStream(inputFileName);
		FileOutputStream fos = null;
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("Visible");
		XSSFRow row = null;
		XSSFCell cell = null;

		row = sheet.getRow(rowNo);
		if (row == null)
			row = sheet.createRow(1);

		cell = row.getCell(4);
		if (cell == null)
			cell = row.createCell(3);

		cell.setCellValue(data);

		fos = new FileOutputStream(inputFileName);
		workbook.write(fos);
		fos.close();
		workbook.close();
	}

	public static void writeData2(int rowNo, String data) throws Exception {

		/*
		 * System.out.println(data+"writeData2_datachecl>>>>>>>>>>>>>>>>>>>>>>>>>>");
		 * System.out.println(rowNo+
		 * "writeData2_row>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		 */
		FileInputStream fis = new FileInputStream(inputFileName);
		FileOutputStream fos = null;
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("TestSuite");
		XSSFRow row = null;
		XSSFCell cell = null;

		System.out.println(data + "Before if>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");

		if (data.equalsIgnoreCase("true")) {

			data = "Pass";

			System.out.println(data + "if>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");

		}

		else {
			data = "Fail";

			System.out.println(data + "else>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");

		}

		row = sheet.getRow(rowNo);
		if (row == null)
			row = sheet.createRow(1);

		cell = row.getCell(9);
		if (cell == null)
			cell = row.createCell(9);

		cell.setCellValue(data);

		fos = new FileOutputStream(inputFileName);
		workbook.write(fos);
		fos.close();
		workbook.close();
	}
	
	public static void clean_test_result_visibility(String submodule) throws Exception{
		//FileInputStream fis = new FileInputStream(
				//"C:\\Users\\vibhor-g\\eclipse-workspace\\HCLToscanaa\\Exceldata\\TestSuite.xlsx");
		FileInputStream fis = new FileInputStream(suiteFileName);
		FileOutputStream fos = null;
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("TestSuite");
		System.out.println(sheet.getLastRowNum());
		XSSFRow row = null;
		//XSSFCell cell = null;
		
		for (int i = 1; i <= sheet.getLastRowNum(); i++) {

			row = sheet.getRow(i);
			if (submodule.equalsIgnoreCase(row.getCell(2).getStringCellValue())) {
				XSSFCell result_cell = row.getCell(9);
	            result_cell.setCellValue("");
	            XSSFCell comments_cell = row.getCell(11);
	            if(comments_cell==null) {
	            	row.createCell(11).setCellValue("");
	            }else {
	            	comments_cell.setCellValue("");
	            }
	       }

	}
	    
		//fos = new FileOutputStream("C:\\Users\\vibhor-g\\eclipse-workspace\\HCLToscanaa\\Exceldata\\TestSuite.xlsx");
		fos = new FileOutputStream(suiteFileName);
		workbook.write(fos);
		fos.close();
		workbook.close();
	}

/*public static void clean_test_result_visibility(String submodule) throws Exception{
	FileInputStream fis = new FileInputStream(
			"C:\\Users\\manisha.chaudhary\\seleniumproject\\Exceldata\\TestSuite.xlsx");
	FileOutputStream fos = null;
	XSSFWorkbook workbook = new XSSFWorkbook(fis);
	XSSFSheet sheet = workbook.getSheet("TestSuite");
	XSSFRow row = null;
	XSSFCell cell = null;
	
	for (int i = 1; i <= sheet.getLastRowNum(); i++) {

		row = sheet.getRow(i);
		if (submodule.equalsIgnoreCase(row.getCell(2).getStringCellValue())) {
			cell = row.getCell(9);

			cell.setCellValue("");
		}

			

		

	}

	

	fos = new FileOutputStream("C:\\Users\\manisha.chaudhary\\seleniumproject\\Exceldata\\TestSuite.xlsx");
	workbook.write(fos);
	fos.close();
	workbook.close();
}*/
	public static void writeData3(String data, String SubModule, String FieldName) throws Exception {

		/*
		 * System.out.println(data+"writeData2_datachecl>>>>>>>>>>>>>>>>>>>>>>>>>>");
		 * System.out.println(rowNo+
		 * "writeData2_row>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		 */
		//FileInputStream fis = new FileInputStream(
				//"C:\\Users\\vibhor-g\\eclipse-workspace\\HCLToscanaa\\Exceldata\\TestSuite.xlsx");
		FileInputStream fis = new FileInputStream(suiteFileName);
		FileOutputStream fos = null;
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("TestSuite");
		XSSFRow row = null;
		XSSFCell cell = null;

		if (data.equalsIgnoreCase("true")) {

			data = "Pass";

		}

		else {
			data = "Fail";

		}

		for (int i = 1; i <= sheet.getLastRowNum(); i++) {

			row = sheet.getRow(i);

			if (SubModule.equalsIgnoreCase(row.getCell(2).getStringCellValue())
					&& FieldName.equalsIgnoreCase(row.getCell(4).getStringCellValue())) {

				cell = row.getCell(9);

				cell.setCellValue(data);

			}

		}

		

		//fos = new FileOutputStream("C:\\Users\\vibhor-g\\eclipse-workspace\\HCLToscanaa\\Exceldata\\TestSuite.xlsx");
		fos = new FileOutputStream(suiteFileName);
		workbook.write(fos);
		fos.close();
		workbook.close();
	}
	
	public static void writeData4(String data, String SubModule) throws Exception {

		/*
		 * System.out.println(data+"writeData2_datachecl>>>>>>>>>>>>>>>>>>>>>>>>>>");
		 * System.out.println(rowNo+
		 * "writeData2_row>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		 */
		FileInputStream fis = new FileInputStream(suiteFileName);
		FileOutputStream fos = null;
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("TestSuite");
		XSSFRow row = null;
		XSSFCell cell = null;

		if (data.equalsIgnoreCase("true")) {

			data = "Pass";

		}

		else {
			data = "Fail";

		}

		for (int i = 1; i <= sheet.getLastRowNum(); i++) {

			row = sheet.getRow(i);

			if (SubModule.equalsIgnoreCase(row.getCell(2).getStringCellValue()))
					{

				cell = row.getCell(9);

				cell.setCellValue(data);

			}

		}

		

		fos = new FileOutputStream(suiteFileName);
		workbook.write(fos);
		fos.close();
		workbook.close();
	}
	
	public static void writeData5(String data, String SubModule, String FieldName) throws Exception {

		/*
		 * System.out.println(data+"writeData2_datachecl>>>>>>>>>>>>>>>>>>>>>>>>>>");
		 * System.out.println(rowNo+
		 * "writeData2_row>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		 */
		FileInputStream fis = new FileInputStream(suiteFileName);
		//FileInputStream fis = new FileInputStream(
				//"C:\\Users\\azureadmin\\Desktop\\Vibhor Gupta\\Exceldata\\TestSuite.xlsx");
		FileOutputStream fos = null;
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet("TestSuite");
		XSSFRow row = null;
		XSSFCell cell = null;

		for (int i = 1; i <= sheet.getLastRowNum(); i++) {

			row = sheet.getRow(i);

			if (SubModule.equalsIgnoreCase(row.getCell(2).getStringCellValue())
					&& FieldName.equalsIgnoreCase(row.getCell(4).getStringCellValue())) {
				
				if(row.getCell(11)==null) {
					row.createCell(11).setCellValue(data);
				}else {
					row.getCell(11).setCellValue(data);
				}

			}

		}

		fos = new FileOutputStream(suiteFileName);
		//fos = new FileOutputStream("C:\\Users\\azureadmin\\Desktop\\Vibhor Gupta\\Exceldata\\TestSuite.xlsx");
		workbook.write(fos);
		fos.close();
		workbook.close();
	}


	/*
	 * public static void WriteResult(String Ress, int DR) throws Exception {
	 * FileInputStream file_input_stream= new FileInputStream(
	 * "C:\\Users\\manisha.chaudhary\\seleniumproject\\Exceldata\\ToscanaInput.xlsx"
	 * ); workbook=new HSSFWorkbook(file_input_stream);
	 * worksheet=workbook.getSheet("Visible"); HSSFRow Row=worksheet.getRow(0);
	 * 
	 * int sheetIndex=workbook.getSheetIndex("Visible"); DataFormatter formatter 
	 * new DataFormatter(); if(sheetIndex==-1) {
	 * System.out.println("No such sheet in file exists"); } else { col_num=-1;
	 * for(int i=0;i<Row.getLastCellNum();i++) { HSSFCell cols=Row.getCell(i);
	 * String colsval=formatter.formatCellValue(cols);
	 * if(colsval.trim().equalsIgnoreCase(ColName.trim())) { col_num=i; break; } }
	 * // Row= worksheet.getRow(DR); try { //get my Row which is equal to Data
	 * Result and that colNum HSSFCell cell=worksheet.getRow(DR).getCell(col_num);
	 * // if no cell found then it create cell if(cell==null) {
	 * cell=Row.createCell(col_num); } //Set Result is pass in that cell number
	 * cell.setCellValue(Ress);
	 * 
	 * 
	 * } catch (Exception e) { System.out.println(e.getMessage()); }
	 * 
	 * } FileOutputStream file_output_stream=new FileOutputStream(
	 * "C:\\Users\\manisha.chaudhary\\seleniumproject\\Exceldata\\ToscanaInput.xlsx"
	 * ); workbook.write(file_output_stream); file_output_stream.close();
	 * if(col_num==-1) {
	 * System.out.println("Column you are searching for does not exist"); } }
	 */
}
