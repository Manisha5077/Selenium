package TNApplication;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITest;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.constant.ToscanaConstant;
import com.util.Utils;

import Resource.Base;



	public class EnableCheck extends Base implements ITest{
		
		public static Logger logger = LogManager.getLogger(FormSubmission.class);

		WebDriverWait wait = new WebDriverWait(driver,40);
		private ThreadLocal<String> testName = new ThreadLocal<>();
		
		SoftAssert softAssertion = new SoftAssert();

		 Map<String,List<String>> map=new HashMap<String,List<String>>();
		 Map<String, List<String>> data=null;
		 static String AlertTextContains=Utils.propertyfromxls("AlertText");

		static int i = 0;
		
		@BeforeClass
		public void clean_test_result() {
			//logger.info("FormSubmission: Inside clean_test_result()");
			 try {
				   TestCasesResultWrite.clean_test_result_visibility(ToscanaConstant.SubModule_enable_check);
				   //TestCasesResultWrite.clean_test_result_visibility(ToscanaConstant.SubModule_input_check);
				   
				   }catch(Exception E) {
					   //logger.error("FormSubmission: Inside clean_test_result(): error {}", E);
					   E.printStackTrace();
				   }
		}


		@Test(dataProvider = "enable-data-provider", dataProviderClass = DP.class, priority = 1,groups="enable")
		public void EnableCheck(String key,List<String> list) throws FileNotFoundException
		
		{ 
			
			//logger.info("FormSubmission: Inside EnableCheck()");
			
			System.out.println("******************************************************INSIDE ENABLE CHECK*****************************************************");
			
			map.put(key, list);
	boolean result = false;
			
			try {
				WebElement element=GenericMethod.Find_element(list.get(2),list.get(0));//2-type,0-path
				if(element!=null) {
					result=element.isEnabled();

					}
				

				Reporter.log(
								key + ToscanaConstant.FIELD_ENABLE); 
				///logger.info(key + ToscanaConstant.FIELD_ENABLE);
				
			}

			catch (Exception e) {
				
		
			}
			try {
				
			TestCasesResultWrite.writeData3(String.valueOf(result), ToscanaConstant.SubModule_enable_check, key);
			
			}catch(Exception E) {             
				E.printStackTrace();
			}
			
			
			try {
				assertEquals(result, true);
				result= true;
					ReportGenerator.onTestSuccess("EnableCheck_"+key);
					}catch(Throwable throwable) {
						result= false;
						ReportGenerator.onTestFailure(throwable, "EnableCheck_"+key);
					}
		}


		@Override
		public String getTestName() {
			// TODO Auto-generated method stub
			return null;
		}
		
	
	
}

