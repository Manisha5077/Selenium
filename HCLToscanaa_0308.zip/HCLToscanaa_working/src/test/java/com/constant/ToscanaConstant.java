package com.constant;

public class ToscanaConstant {
	
	public static final String CHROME_DRIVER="webdriver.chrome.driver";
	
	public static final String GECKO_DRIVER="webdriver.gecko.driver";
	
	public static final String IE_DRIVER="webdriver.ie.driver";
	
	public static final String LABEL_TXT_SAME="Label text and Excel/Expected text are same";
	
	public static final String LABEL_TXT_NOT_SAME="LABEL TEXT AND EXCEL/EXPECTED TEXT ARE NOT SAME";
	
	public static final String FIELD_VISIBLE="field is visible";
	
	public static final String FIELD_NOT_VISIBLE="VISIBILITY FAILED FOR THIS FIELD";
	
	public static final String FIELD_ENABLE="field is enable";
	
	public static final String FIELD_NOT_ENABLE="FAILED FOR THIS FIELD";
	
	public static final String FIELD_NOT_INPUT="FAILED FOR THIS FIELD";
	
	
	public static final String SubModule_Visilbility_check= "Field Visibility Check";
	
	public static final String SubModule_enable_check= "Field Enable Check";
	
	public static final String SubModule_input_check= "Form Field Indexing";
	
	public static final String SubModule_mandatory_check= "Field Mandatory Check";
	
	public static final String SubModule_Length_check= "Field Length Check";
	
	public static final String SubModule_DataType_check= "Field DataType Check";
	
	public static final String SubModule_WI_search= "WI Search Check";
	
	public static final String SubModule_dataloss_check= "Data Loss Check";
}
