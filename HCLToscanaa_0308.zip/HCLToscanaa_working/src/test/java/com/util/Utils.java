package com.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

import Resource.Base;
import TNApplication.GenericMethod;

public class Utils {

	public static Logger logger = LogManager.getLogger(Base.class);
	public static WebDriver driver=null;
	public static String url=null;
	protected static Properties prop=null;

	static {

		prop = new Properties();

		FileInputStream fis2 = null;
		try {
			fis2 = new FileInputStream(System.getProperty("user.dir")+"\\application.properties");
		} catch (FileNotFoundException e1) { 
			e1.printStackTrace();
		}

		try {
			prop.load(fis2);
		}

		catch (IOException e) { 
			e.printStackTrace();
		}
		
		Base.browser();

		

		
		
	}
	
	public static String propertyfromxls(String name) {
		FileInputStream fis = null;
		String value = null;
		
	
		
		try {
			/*fis = new FileInputStream(
					"C:\\Users\\manisha.chaudhary\\eclipse-workspace\\HCLToscanaa\\Exceldata\\ToscanaInput.xlsx");*/
			//System.out.println("path of property>>>>>>>>>"+(System.getProperty("user.dir")+prop.getProperty("xlsx.file.path")));		
			fis = new FileInputStream(System.getProperty("user.dir")+prop.getProperty("xlsx.file.path"));
			
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		XSSFWorkbook objectdata = null;// objectdata is object for excel
		try {
			objectdata = new XSSFWorkbook(fis);

		} catch (IOException e) {

			e.printStackTrace();
		}

		for (int i = 0; i < objectdata.getNumberOfSheets(); i++) {
			if (objectdata.getSheetName(i).equalsIgnoreCase(prop.getProperty("config.sheet.name"))) {
				XSSFSheet objectsheet = objectdata.getSheetAt(i);

				for (int j = 0; j < objectsheet.getLastRowNum(); j++) {
					XSSFRow row = objectsheet.getRow(j);
					if (row.getCell(0).getStringCellValue().equalsIgnoreCase(name)) {
						value = row.getCell(1).getStringCellValue();
						break;
					}

				}

			}

		}
		GenericMethod.closeexcel(objectdata);
		return value;
		
		

	}

	
}
