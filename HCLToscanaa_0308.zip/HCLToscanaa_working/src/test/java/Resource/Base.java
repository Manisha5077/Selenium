package Resource;

import java.io.File;
//import java.io.File;
import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
//import java.util.Map;
import java.util.Properties;

import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
//import org.apache.poi.hssf.usermodel.HSSFWorkbook;
//import org.apache.poi.ss.usermodel.Sheet;
//import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.firefox.FirefoxDriver;

import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.ITestContext;
import org.testng.annotations.BeforeMethod;

import com.constant.ToscanaConstant;
import com.google.errorprone.annotations.Var;

import TNApplication.GenericMethod;
import TNApplication.ToscanaLogin;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
 
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Base {
	
	public static Logger logger = LogManager.getLogger(Base.class);
	public static WebDriver driver=null;
	public static String url=null;
	protected static Properties prop=null;
	
	static {

		prop = new Properties();

		FileInputStream fis2 = null;
		try {
			fis2 = new FileInputStream(System.getProperty("user.dir")+"\\application.properties");
		} catch (FileNotFoundException e1) { 
			e1.printStackTrace();
		}

		try {
			prop.load(fis2);
		}

		catch (IOException e) { 
			e.printStackTrace();
		}
		
		Base.browser();

		
	}
	
	
	public String propertyfromxls(String name) {
		FileInputStream fis = null;
		String value = null;
		
		//System.out.println("I am called!!!!!!");
		
		try {
			/*fis = new FileInputStream(
					"C:\\Users\\manisha.chaudhary\\eclipse-workspace\\HCLToscanaa\\Exceldata\\ToscanaInput.xlsx");*/
			//System.out.println("path of property>>>>>>>>>"+(System.getProperty("user.dir")+prop.getProperty("xlsx.file.path")));		
			fis = new FileInputStream(System.getProperty("user.dir")+prop.getProperty("xlsx.file.path"));
			
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		XSSFWorkbook objectdata = null;// objectdata is object for excel
		try {
			objectdata = new XSSFWorkbook(fis);

		} catch (IOException e) {

			e.printStackTrace();
		}

		for (int i = 0; i < objectdata.getNumberOfSheets(); i++) {
			if (objectdata.getSheetName(i).equalsIgnoreCase(prop.getProperty("config.sheet.name"))) {
				XSSFSheet objectsheet = objectdata.getSheetAt(i);

				for (int j = 0; j < objectsheet.getLastRowNum(); j++) {
					XSSFRow row = objectsheet.getRow(j);
					if (row.getCell(0).getStringCellValue().equalsIgnoreCase(name)) {
						value = row.getCell(1).getStringCellValue();
						break;
					}

				}

			}

		}
		GenericMethod.closeexcel(objectdata);
		return value;
		
		

	}

	
	
		  
		public static void browser() {
		Base b = new Base();

		String browserName = b.propertyfromxls("browser");// Base.("browser");
		// url = b.propertyfromxls("url");
		
		//String browserName = prop.getProperty("browser");// Base.("browser");

		if (browserName.equals("chrome"))

		{

			System.setProperty(ToscanaConstant.CHROME_DRIVER, System.getProperty("user.dir")+prop.getProperty("chrome.driver.path"));

			driver = new ChromeDriver();
			

		}

		else if (browserName.equals("firefox")) {

			System.setProperty(ToscanaConstant.GECKO_DRIVER, System.getProperty("user.dir")+prop.getProperty("firefox.driver.path"));

			driver = new FirefoxDriver();

		}

		else if (browserName.equals("IE")) {

			System.setProperty(ToscanaConstant.IE_DRIVER, System.getProperty("user.dir")+prop.getProperty("ie.driver.path"));

			driver = new InternetExplorerDriver();

		}

		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		logger.info("Base: Window Maximized");
	
	}
	
	public static String dateTimeGenerator()
	{
	Format formatter = new SimpleDateFormat("YYYYMMdd_HHmmssSSS");
	Date date = new Date(System.currentTimeMillis());
	return formatter.format(date);
	}
	
	
	
	public String getScreenShotPath(String testCaseName) throws IOException
	{
		//testCaseName+=dateTimeGenerator();
		
		TakesScreenshot ts=(TakesScreenshot)driver;
		File source =ts.getScreenshotAs(OutputType.FILE);
		//String destinationFile = System.getProperty("user.dir")+"\\reports\\"+testCaseName+".png";
		String destinationFile =prop.getProperty("extent.report.path")+dateTimeGenerator()+testCaseName+".png";
		
		FileUtils.copyFile(source,new File(destinationFile));
		return destinationFile;


	}
	
	
	public static String getScreenShotPathStatic(String testCaseName) throws IOException
	{
		//testCaseName+=dateTimeGenerator();
		
		TakesScreenshot ts=(TakesScreenshot)driver;
		File source =ts.getScreenshotAs(OutputType.FILE);
		//String destinationFile = System.getProperty("user.dir")+"\\reports\\"+testCaseName+".png";
		String destinationFile =prop.getProperty("extent.report.path")+dateTimeGenerator()+testCaseName+".png";
		
		FileUtils.copyFile(source,new File(destinationFile));
		return destinationFile;


	}
	  
	
	}
	
	
	


