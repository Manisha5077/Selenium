package Resource;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReporterNG extends Base {

	static ExtentReports extent;
	
	public static String dateTimeGenerator()
	{
	Format formatter = new SimpleDateFormat("YYYYMMdd_HHmmssSSS");
	Date date = new Date(System.currentTimeMillis());
	return formatter.format(date);
	}
	
	
	public static ExtentReports getReportObject()
	{
		
		//String path =System.getProperty("user.dir")+"\\reports"+dateTimeGenerator()+"\\index.html";
		String path =prop.getProperty("extent.report.path")+dateTimeGenerator()+"\\index.html";
		ExtentSparkReporter reporter = new ExtentSparkReporter(path);
		reporter.config().setReportName("Toscana Automation Results");
		reporter.config().setDocumentTitle("Test Results");
		
		 extent =new ExtentReports();
		extent.attachReporter(reporter);
		extent.setSystemInfo("Tester", "Manisha Chaudhary");
		return extent;
		
	}

		
		
	}
	
	

